#!/bin/bash

# Check if openocd is already running
if ps ax | grep -v grep | grep -w openocd > /dev/null
then
    echo "OpenOcd is already  running. Restart"
    killall openocd
else
    echo "Start OpenOcd"
fi

openocd -f interface/jlink.cfg -f target/stm32f1x.cfg 2> /dev/null &
sleep 2
