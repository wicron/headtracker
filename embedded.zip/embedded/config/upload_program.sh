#!/bin/bash


config_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
build_dir=$config_dir/../build
echo "I suppose that build dir is .. " $build_dir;

sh $config_dir/run_openocd.sh

if [ -e $build_dir/gdb_upload_program ]
then
    echo "File with commands for gdb is already exists."
else
    echo "Write commands for gdb to file build/gdb_upload_program"
    {
	echo "target remote localhost:3333"
	echo "monitor reset halt"
	echo "file $build_dir/src/head_tracker.elf"
	echo "monitor flash write_image erase $build_dir/src/head_tracker.elf 0 elf"
	echo "Quit"
    } > $build_dir/gdb_upload_program
fi

echo
arm-none-eabi-gdb -x $build_dir/gdb_upload_program
