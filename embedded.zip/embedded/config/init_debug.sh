#!/bin/bash

config_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
build_dir=$config_dir/../build
echo "I suppose that build dir is .. " $build_dir;

sh $config_dir/run_openocd.sh

filename=gdb_init
if [ -e $build_dir/$filename ]
then
    echo "File with commands for gdb is already exists."
else
    echo "Write commands for gdb to file build/$filename"
    {
	echo "target remote localhost:3333"
	echo "monitor reset halt"
	echo "Quit"
    } > $build_dir/$filename
fi

echo
arm-none-eabi-gdb -x $build_dir/$filename
