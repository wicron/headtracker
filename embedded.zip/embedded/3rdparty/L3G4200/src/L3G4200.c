/**
  * @file    L3G4200.c
  * @author  ART Team IMS-Systems Lab
  * @version V2.3.0
  * @date    02 September 2011
  * @brief   This file provides a set of functions needed to manage the
  *          communication between STM32 I2C master and L3G4200 I2C slave.
  * @details
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * THIS SOURCE CODE IS PROTECTED BY A LICENSE.
  * FOR MORE INFORMATION PLEASE CAREFULLY READ THE LICENSE AGREEMENT FILE LOCATED
  * IN THE ROOT DIRECTORY OF THIS FIRMWARE PACKAGE.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  */


/* Includes */
#include "L3G4200.h"
#include "HAL_L3G4200.h"
//#include "iNEMO_conf.h"


/**
* @defgroup L3G4200
* @{
*/

/** @defgroup L3G4200_I2C_Function
* @{
*/

/**
* @brief  Initializes the I2C peripheral used to drive the L3G4200
* @param  None
* @retval None
*/
void L3G4200_I2C_Init(void)
{
  I2C_InitTypeDef  I2C_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Enable I2C and GPIO clocks */
  RCC_APB1PeriphClockCmd(L3G_I2C_RCC_Periph, ENABLE);
  RCC_APB2PeriphClockCmd(L3G_I2C_RCC_Port, ENABLE);

  /* Configure I2C pins: SCL and SDA */
  GPIO_InitStructure.GPIO_Pin =  L3G_I2C_SCL_Pin | L3G_I2C_SDA_Pin;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
  GPIO_Init(L3G_I2C_Port, &GPIO_InitStructure);

  /* I2C configuration */
  I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
  I2C_InitStructure.I2C_OwnAddress1 = 0x00;
  I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
  I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  I2C_InitStructure.I2C_ClockSpeed = L3G_I2C_Speed;

  /* Apply I2C configuration after enabling it */
  I2C_Init(L3G_I2C, &I2C_InitStructure);

  /* I2C Peripheral Enable */
  I2C_Cmd(L3G_I2C, ENABLE);
}

/**
* @brief  Writes one byte to the  L3G4200.
* @param  slAddr : slave address L3G_I2C_ADDRESS or L3G_M_I2C_ADDRESS
* @param  pBuffer : pointer to the buffer  containing the data to be written to the L3G4200.
* @param  WriteAddr : address of the register in which the data will be written
* @retval None
*/
void L3G4200_I2C_ByteWrite(u8 slAddr, u8* pBuffer, u8 WriteAddr)
{
 // iNEMO_ENTER_CRITICAL();
  /* Send START condition */
  I2C_GenerateSTART(L3G_I2C, ENABLE);

  /* Test on EV5 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_MODE_SELECT));

  /* Send L3G4200_Magn address for write */
  I2C_Send7bitAddress(L3G_I2C, slAddr, I2C_Direction_Transmitter);

  /* Test on EV6 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

  /* Send the L3G4200_Magn's internal address to write to */
  I2C_SendData(L3G_I2C, WriteAddr);

  /* Test on EV8 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

  /* Send the byte to be written */
  I2C_SendData(L3G_I2C, *pBuffer);

  /* Test on EV8 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

  /* Send STOP condition */
  I2C_GenerateSTOP(L3G_I2C, ENABLE);
 // iNEMO_EXIT_CRITICAL();
}

/**
* @brief  Reads a block of data from the L3G4200.
* @param  slAddr  : slave address L3G_I2C_ADDRESS or L3G_M_I2C_ADDRESS
* @param  pBuffer : pointer to the buffer that receives the data read from the L3G4200.
* @param  ReadAddr : L3G4200's internal address to read from.
* @param  NumByteToRead : number of bytes to read from the L3G4200 ( NumByteToRead >1  only for the Mgnetometer readinf).
* @retval None
*/

void L3G4200_I2C_BufferRead(u8 slAddr, u8* pBuffer, u8 ReadAddr, u16 NumByteToRead)
{
//  iNEMO_ENTER_CRITICAL();
  /* While the bus is busy */
  while(I2C_GetFlagStatus(L3G_I2C, I2C_FLAG_BUSY));

  /* Send START condition */
  I2C_GenerateSTART(L3G_I2C, ENABLE);

  /* Test on EV5 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_MODE_SELECT));

  /* Send L3G4200_Magn address for write */
  I2C_Send7bitAddress(L3G_I2C, slAddr, I2C_Direction_Transmitter);

  /* Test on EV6 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED));

  /* Clear EV6 by setting again the PE bit */
  I2C_Cmd(L3G_I2C, ENABLE);

  /* Send the L3G4200_Magn's internal address to write to */
  I2C_SendData(L3G_I2C, ReadAddr);

  /* Test on EV8 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_BYTE_TRANSMITTED));

  /* Send STRAT condition a second time */
  I2C_GenerateSTART(L3G_I2C, ENABLE);

  /* Test on EV5 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_MODE_SELECT));

  /* Send L3G4200 address for read */
  I2C_Send7bitAddress(L3G_I2C, slAddr, I2C_Direction_Receiver);

  /* Test on EV6 and clear it */
  while(!I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED));

  /* While there is data to be read */
  while(NumByteToRead)
  {
    if(NumByteToRead == 1)
    {
      /* Disable Acknowledgement */
      I2C_AcknowledgeConfig(L3G_I2C, DISABLE);

      /* Send STOP Condition */
      I2C_GenerateSTOP(L3G_I2C, ENABLE);
    }

    /* Test on EV7 and clear it */
    if(I2C_CheckEvent(L3G_I2C, I2C_EVENT_MASTER_BYTE_RECEIVED))
    {
      /* Read a byte from the L3G4200 */
      *pBuffer = I2C_ReceiveData(L3G_I2C);

      /* Point to the next location where the byte read will be saved */
      pBuffer++;

      /* Decrement the read bytes counter */
      NumByteToRead--;
    }
  }

  /* Enable Acknowledgement to be ready for another reception */
  I2C_AcknowledgeConfig(L3G_I2C, ENABLE);
 // iNEMO_EXIT_CRITICAL();
}
/**
 * @}
 */ /* end of group L3G4200_I2C_Function */

/**
 * @addtogroup Accelerometer
 * @{
 */


/**
* @defgroup Accelerometer_Function
* @{
*/

/**
* @brief  Set configuration of Linear Acceleration measurement of L3G4200
* @param  L3G_Config_Struct : pointer to a L3G_ConfigTypeDef structure that contains the configuration setting for the Accelerometer L3G4200.
* @retval None
*/

void L3G4200_Config(L3G_ConfigTypeDef *L3G_Config_Struct)
{
  u8 CRTL1  = 0x00;
  u8 CRTL4  = 0x00;
  u8 CRTL3  = 0b00001000;

  CRTL1 |= (u8) (L3G_Config_Struct->Power_Mode | L3G_Config_Struct->ODR| L3G_Config_Struct->Axes_Enable);
  CRTL4 |= (u8) (L3G_Config_Struct->FS | L3G_Config_Struct->Data_Update| L3G_Config_Struct->Endianess);

  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS, &CRTL1, L3G_CTRL_REG1_ADDR);
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS, &CRTL3, L3G_CTRL_REG3_ADDR);
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS, &CRTL4, L3G_CTRL_REG4_ADDR);

}

/**
* @brief  Set configuration of  Internal High Pass Filter of  L3G4200 for the linear acceleration
* @param  L3G4200_Filter_ConfigTypeDef : pointer to a L3G4200_ConfigTypeDef structure that
*           contains the configuration setting for the L3G4200.
* @retval None
*/

void L3G4200_Filter_Config(L3G_Filter_ConfigTypeDef *L3G_Filter_Config_Struct)
{
  u8 CRTL2 = 0x00;
  u8 REF  =  0x00;


  CRTL2 |= (u8) (L3G_Filter_Config_Struct->HPF_Enable | L3G_Filter_Config_Struct->HPF_Mode| L3G_Filter_Config_Struct->HPF_Frequency);
  REF |= (u8) (L3G_Filter_Config_Struct->HPF_Reference);

  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS, &CRTL2, L3G_CTRL_REG2_ADDR);
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS, &REF, L3G_REFERENCE_REG_ADDR);
}

/**
* @brief  Change the lowpower mode for Accelerometer of L3G4200
* @param  LowPowerMode : new state for the lowpower mode. This parameter can be: L3G4200_Lowpower_x see L3G4200_SPI.h file
* @retval None
*/
void L3G4200_Lowpower_Cmd(u8 LowPowerMode)
{
  u8 tmpreg;
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &tmpreg, L3G_CTRL_REG1_ADDR, 1);
  tmpreg &= 0x1F;
  tmpreg |= LowPowerMode;
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS,&tmpreg, L3G_CTRL_REG1_ADDR);
}

/**
* @brief  Change the ODR(Output data rate) for Acceleromter of L3G4200
* @param  DataRateValue : new ODR value. This parameter can be: L3G4200_ODR_x see L3G4200_SPI.h file
* @retval None
*/

void L3G4200_DataRate_Cmd(u8 DataRateValue)
{
  u8 tmpreg;
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &tmpreg, L3G_CTRL_REG1_ADDR, 1);
  tmpreg &= 0xE7;
  tmpreg |= DataRateValue;
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS,&tmpreg, L3G_CTRL_REG1_ADDR);
}

/**
* @brief  Change the Full Scale of L3G4200
* @param  FS_value : new full scale value. This parameter can be: L3G4200_FS_x  see L3G4200_SPI.h file
* @retval None
*/

void L3G4200_FullScale_Cmd(u8 FS_value)
{
  u8 tmpreg;
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &tmpreg, L3G_CTRL_REG4_ADDR, 1);
  tmpreg &= 0xCF;
  tmpreg |= FS_value;
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS,&tmpreg, L3G_CTRL_REG4_ADDR);
}

/**
* @brief  Reboot memory content of L3G4200
* @param  None
* @retval None
*/

void L3G4200_Reboot_Cmd(void)
{
  u8 tmpreg;
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &tmpreg, L3G_CTRL_REG2_ADDR, 1);
  tmpreg |= 0x80;
  L3G4200_I2C_ByteWrite(L3G_I2C_ADDRESS,&tmpreg, L3G_CTRL_REG2_ADDR);
}

/**
* @brief  Read L3G4200 linear acceleration output register
* @param  out : buffer to store data
* @retval None
*/

void L3G_Read_OutReg(u8* out)
{
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, out, (L3G_OUT_X_L_ADDR | 0x80), 6);
}

/**
* @brief   Read L3G4200 output register, and calculate the raw  acceleration [LSB] ACC= (out_h*256+out_l)/16 (12 bit rappresentation)
* @param  out : buffer to store data
* @retval None
*/

void L3G4200_Read_RawData(s16* out)
{
  u8 buffer[6];
  u8 crtl4;
  
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &crtl4, L3G_CTRL_REG4_ADDR, 1);
  
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[0], L3G_OUT_X_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[1], L3G_OUT_X_H_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[2], L3G_OUT_Y_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[3], L3G_OUT_Y_H_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[4], L3G_OUT_Z_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[5], L3G_OUT_Z_H_ADDR, 1);
  
  /* check in the control register4 the data alignment*/
  if(!(crtl4 & 0x40))
  {
    for(int i=0; i<3; i++)
    {
      out[i]=(s16)(((u16)buffer[2*i+1] << 8) + buffer[2*i]);
    }
  }
  else
  {  
    for(int i=0; i<3; i++)
      out[i]=((s16)((u16)buffer[2*i] << 8) + buffer[2*i+1]);
  }
}


/**
* @brief   Read L3G4200 output register, and calculate the acceleration ACC=SENSITIVITY* (out_h*256+out_l)/16 (12 bit rappresentation)
* @param  out : buffer to store data
* @retval None
*/

void L3G4200_Read_Acc(s16* out)
{
  u8 buffer[6];
  u8 crtl4;

  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &crtl4, L3G_CTRL_REG4_ADDR, 1);

  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[0], L3G_OUT_X_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[1], L3G_OUT_X_H_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[2], L3G_OUT_Y_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[3], L3G_OUT_Y_H_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[4], L3G_OUT_Z_L_ADDR, 1);
  L3G4200_I2C_BufferRead(L3G_I2C_ADDRESS, &buffer[5], L3G_OUT_Z_H_ADDR, 1);

  /* check in the control register4 the data alignment*/
  if(!(crtl4 & 0x40))
  {
    /* switch the sensitivity value set in the CRTL4*/
    switch(crtl4 & 0x30)
    {
    case 0x00:
      for(int i=0; i<3; i++)
      {
        out[i]=(s16)(((u16)buffer[2*i+1] << 8) + buffer[2*i])/(32767/L3G_Sensitivity_250dps);
      }
      break;
    case 0x10:
      for(int i=0; i<3; i++)
        out[i]=(s16)(((u16)buffer[2*i+1] << 8) + buffer[2*i])/(32767/L3G_Sensitivity_500dps);
      break;
    case 0x30:
      for(int i=0; i<3; i++)
        out[i]=(s16)(((u16)buffer[2*i+1] << 8) + buffer[2*i])/(32767/L3G_Sensitivity_2000dps);
      break;
    }
  }
  else
  {
    switch(crtl4 & 0x30)
    {
    case 0x00:
      for(int i=0; i<3; i++)
        out[i]=((s16)((u16)buffer[2*i] << 8) + buffer[2*i+1])/(32767/L3G_Sensitivity_250dps);
      break;
    case 0x10:
      for(int i=0; i<3; i++)
        out[i]=((s16)((u16)buffer[2*i] << 8) + buffer[2*i+1])/(32767/L3G_Sensitivity_500dps);
      break;
    case 0x30:
      for(int i=0; i<3; i++)
        out[i]=((s16)((u16)buffer[2*i] << 8) + buffer[2*i+1])/(32767/L3G_Sensitivity_2000dps);
      break;
    }
  }
}

void L3G4200_DRDY_Config(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Enable _MAG_DRDY pad GPIO clocks */
  RCC_APB2PeriphClockCmd(L3G_DRDY_RCC_Port, ENABLE);

  /* Configure MAG_DRDY pin as input floating */
  GPIO_InitStructure.GPIO_Pin = L3G_DRDY_Pin;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(L3G_DRDY_Port, &GPIO_InitStructure);

  /* Connect MAG_DRDY_EXTI_Line to MAG_DRDY Pin */
  GPIO_EXTILineConfig(L3G_DRDY_Port_Source, L3G_DRDY_Pin_Source);

  /* Configure MAG_DRDY_EXTI_Line to generate an interrupt on MAG_DRDY_Edge edge */
  EXTI_InitStructure.EXTI_Line = L3G_DRDY_EXTI_Line;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = L3G_DRDY_Edge;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  /* Enable the MAG_DRDY_EXTI_IRQCHANNEL Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = L3G_DRDY_EXTI_IRQCHANNEL;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = L3G_DRDY_Preemption_Priority;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = L3G_DRDY_Sub_Priority;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}


void L3G_Config(void)
{
	L3G_ConfigTypeDef  L3G_Gyro_InitStructure;
    L3G_Filter_ConfigTypeDef L3G_Gyro_FilterStructure;

    L3G_Gyro_InitStructure.Power_Mode = L3G_Normal;
    L3G_Gyro_InitStructure.ODR = L3G_ODR_100_LPF25 ;
    L3G_Gyro_InitStructure.Axes_Enable= L3G_XYZEN;
    L3G_Gyro_InitStructure.FS = L3G_FS_250;
    L3G_Gyro_InitStructure.Data_Update = L3G_BDU_Continuos;
    L3G_Gyro_InitStructure.Endianess=L3G_Little_Endian;

    L3G4200_Config (&L3G_Gyro_InitStructure);

    L3G_Gyro_FilterStructure.HPF_Enable=L3G_HP_Filter_Disable;
    L3G_Gyro_FilterStructure.HPF_Mode=L3G_FilterMode_Normal;
    L3G_Gyro_FilterStructure.HPF_Reference=0x00;
    L3G_Gyro_FilterStructure.HPF_Frequency=L3G_Filter_HP_ODR_div100;

    L3G4200_Filter_Config(&L3G_Gyro_FilterStructure);
    L3G4200_DRDY_Config();
}

/**
*@}
*/ /* end of group Accelerometer_Function */


/**
 * @}
 */ /* end of group Accelerometer */

/**
 * @addtogroup Magnetometer
 * @{
 */

/**
* @defgroup Magnetometer_Function
* @{
*/

/**
* @brief  Set configuration of Magnetic field measurement of L3G4200
* @param  L3G_Magn_Config_Struct :  pointer to L3G_Magn_ConfigTypeDef structure that
*                  contains the configuration setting for the L3G4200_Magn.
* @retval None
*/



/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
