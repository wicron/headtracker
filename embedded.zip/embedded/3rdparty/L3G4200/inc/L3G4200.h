/**
  * @file    LSM303DLH.h
  * @author  ART Team IMS-Systems Lab + delphi
  * @version V2.3.0
  * @date    02 September 2011
  * @brief   Header for L3G4200.c file
  * @details
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * THIS SOURCE CODE IS PROTECTED BY A LICENSE.
  * FOR MORE INFORMATION PLEASE CAREFULLY READ THE LICENSE AGREEMENT FILE LOCATED
  * IN THE ROOT DIRECTORY OF THIS FIRMWARE PACKAGE.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  */



/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __L3G4200_H
#define __L3G4200_H

/* Includes ------------------------------------------------------------------*/
#include "HAL_L3G4200.h"

#ifdef __cplusplus
 extern "C" {
#endif


#define L3G_Sensitivity_250dps               250
#define L3G_Sensitivity_500dps               500
#define L3G_Sensitivity_2000dps              2000

#define L3G_Lowpower_NormalMode             ((u8)0x20)
#define L3G_Lowpower_05                     ((u8)0x40)
#define L3G_Lowpower_1                      ((u8)0x60)
#define L3G_Lowpower_2                      ((u8)0x80)
#define L3G_Lowpower_5                      ((u8)0xA0)
#define L3G_Lowpower_10                     ((u8)0xC0)

#define L3G_ODR_100_LPF12                	((u8)0b00000000)
#define L3G_ODR_100_LPF25                   ((u8)0b00010000)
#define L3G_ODR_200_LPF25                   ((u8)0b01010000)
#define L3G_ODR_200_LPF50                   ((u8)0b01100000)
#define L3G_ODR_200_LPF70                   ((u8)0b01110000)

#define L3G_ODR_400_LPF20                   ((u8)0b10010000)
#define L3G_ODR_400_LPF25                   ((u8)0b10010000)
#define L3G_ODR_400_LPF50                   ((u8)0b10100000)
#define L3G_ODR_400_LPF110                  ((u8)0b10110000)

#define L3G_ODR_800_LPF30                   ((u8)0b11010000)
#define L3G_ODR_800_LPF35                   ((u8)0b11010000)
#define L3G_ODR_800_LPF50                   ((u8)0b11100000)
#define L3G_ODR_800_LPF110                  ((u8)0b11110000)

#define L3G_XEN                             ((u8)0x01)
#define L3G_YEN                             ((u8)0x02)
#define L3G_ZEN                             ((u8)0x04)
#define L3G_XYZEN                           ((u8)0x07)

#define L3G_Normal                          ((u8)0b00001000)

#define L3G_FS_250                          ((u8)0x00)
#define L3G_FS_500                          ((u8)0b00010000)
#define L3G_FS_2000                         ((u8)0b00110000)

#define L3G_Little_Endian                   ((u8)0x00)
#define L3G_Big_Endian                      ((u8)0x40)

#define L3G_BDU_Continuos                   ((u8)0x00)
#define L3G_BDU_Single                      ((u8)0x80)

#define L3G_FilterMode_Normal               ((u8)0b00100000)
#define L3G_FilterMode_Reference            ((u8)0b00010000)
#define L3G_HP_Filter_Disable                        0
#define L3G_HP_Filter_Enable                ((u8)0b00010001)
#define L3G_LP_Filter_Enable                ((u8)0b00000010)
#define L3G_LP_HP_Filter_Enable             ((u8)0b00010110)

#define L3G_Filter_HP_ODR_div12              ((u8)0b00000000)   //this HPF calculated as ODR/number (the datasheet describes this)
#define L3G_Filter_HP_ODR_div25              ((u8)0b00000001)
#define L3G_Filter_HP_ODR_div50              ((u8)0b00000010)
#define L3G_Filter_HP_ODR_div100             ((u8)0b00000011)
#define L3G_Filter_HP_ODR_div200             ((u8)0b00000100)
#define L3G_Filter_HP_ODR_div500             ((u8)0b00000101)
#define L3G_Filter_HP_ODR_div1000            ((u8)0b00000110)
#define L3G_Filter_HP_ODR_div2000            ((u8)0b00000111)
#define L3G_Filter_HP_ODR_div5000            ((u8)0b00001000)
#define L3G_Filter_HP_ODR_div10000           ((u8)0b00001001)

#define Bypass                          ((u8)0b00000000)
#define FIFO                            ((u8)0b00100000)
#define Stream                          ((u8)0b01000000)
#define StreamToFIFO                    ((u8)0b01100000)
#define BypassToFIFO                    ((u8)0b10000000)
/**
*  \brief Gyro I2C Slave Address
*/
#define L3G_I2C_ADDRESS        0xD2   //warning!!! change to correct. //Changed!!!

#define L3G_CTRL_REG1_ADDR     0x20

#define L3G_CTRL_REG2_ADDR     0x21

#define L3G_CTRL_REG3_ADDR     0x22

#define L3G_CTRL_REG4_ADDR     0x23

#define L3G_CTRL_REG5_ADDR     0x24

#define L3G_CTRL_INT_REF_ADDR  0x24

#define L3G_TEMP_ADDR          0x26

#define L3G_STATUS_REG_ADDR    0x27

#define L3G_OUT_X_L_ADDR       0x28

#define L3G_FIFO_CTRL_REG_ADDR 0x2E

#define L3G_REFERENCE_REG_ADDR 0x25

/**
*  \brief  Acceleration X-axis Output Data MSB Register
*  \code
*  Default value: ( The value is expressed as 16bit two�s complement)
*  7:0 XOUT15-XOUT8: ACC Data MSB (if in Little Endian Mode --> BLE bit in CTRL_REG1 is 0)
*                    ACC Data LSB (if in Big Endian Mode --> BLE bit in CTRL_REG1 is 1)
* \endcode
*/
#define L3G_OUT_X_H_ADDR     0x29

/**
*  \brief Acceleration Y-axis Output Data LSB Register
*  \code
*  Read
*  Default value: ( The value is expressed as 16bit two�s complement)
*  7:0 YOUT7-YOUT0: ACC Data LSB (if in Little Endian Mode --> BLE bit in CTRL_REG4 is 0)
*                   ACC Data MSB (if in Big Endian Mode --> BLE bit in CTRL_REG4 is 1)
* \endcode
*/
#define L3G_OUT_Y_L_ADDR     0x2A

/**
*  \brief  Acceleration Y-axis Output Data MSB Register
*  \code
*   Read register
*   Default value:  ( The value is expressed as 16bit two�s complement)
*   7:0 YOUT15-YOUT8: ACC Data MSB (if in Little Endian Mode --> BLE bit in CTRL_REG1 is 0)
*                   ACC Data LSB (if in Big Endian Mode --> BLE bit in CTRL_REG1 is 1)
* \endcode
*/
#define L3G_OUT_Y_H_ADDR     0x2B


/**
*  \brief  Acceleration Z-axis Output Data LSB Register
*  \code
*  Read
*  Default value: ( The value is expressed as 16bit two�s complement)
*  7:0 YOUT7-YOUT0: ACC Data LSB (if in Little Endian Mode --> BLE bit in CTRL_REG4 is 0)
*                   ACC Data MSB (if in Big Endian Mode --> BLE bit in CTRL_REG4 is 1)
* \endcode
*/
#define L3G_OUT_Z_L_ADDR     0x2C

/**
*  \brief  Acceleration Z-axis Output Data MSB Register
*  \code
*  Default value: ( The value is expressed as 16bit two�s complement)
*  7:0 YOUT15-YOUT8: ACC Data MSB (if in Little Endian Mode --> BLE bit in CTRL_REG1 is 0)
*                   ACC Data LSB (if in Big Endian Mode --> BLE bit in CTRL_REG1 is 1)
*   \endcode
*/
#define L3G_OUT_Z_H_ADDR     0x2D

/**
*  \brief Accelerometer Configuration Register for Interrupt 1 source.
*  \code
*  Read
*  Default value: 0x00
*  5 ZHIE:  Enable interrupt generation on Z high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  4 ZLIE:  Enable interrupt generation on Z low event. 0: disable interrupt request;  1: enable interrupt request on measured accel. value lower than preset threshold
*  3 YHIE:  Enable interrupt generation on Y high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  2 YLIE:  Enable interrupt generation on Y low event. 0: disable interrupt request;  1: enable interrupt request on measured accel. value lower than preset threshold
*  1 XHIE:  Enable interrupt generation on X high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  0 XLIE:  Enable interrupt generation on X low event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value lower than preset threshold
*
*             AOI     |   6D         | Interrupt mode
*        --------------------------------------------------------
*              0      |       0      | OR combination of interrupt events
*              0      |       1      | 6 direction movement recognition
*              1      |       0      | AND combination of interrupt events
*              1      |       1      |  6 direction position recognition
*
*  \endcode
*/


#define L3G_INT1_CFG_REG_ADDR 0x30

/**
*  \brief Accelerometer Interrupt 1 source register.
*  \code
*  Read only register.
*  Reading at this address clears INT1_SRC IA bit (and the interrupt signal on INT 1 pin) and
*  allows the refreshment of data in the INT1_SRC register if the latched option was chosen.
*  Read
*  Default value: 0x00
*  7 0
*  6 IA : Interrupt active. 0: no interrupt has been generated; 1: one or more interrupts have been generated
*  5 ZH:  Z high. 0: no interrupt, 1: Z High event has occurred
*  4 ZL:  Z low. 0: no interrupt; 1: Z Low event has occurred
*  3 YH:  Y high. 0: no interrupt, 1: Y High event has occurred
*  2 YL:  Y low. 0: no interrupt; 1: Y Low event has occurred
*  1 YH:  X high. 0: no interrupt, 1: X High event has occurred
*  0 YL:  X low. 0: no interrupt; 1: X Low event has occurred
* \endcode
*/
#define L3G_INT1_SCR_REG_ADDR 0x31

/**
*  \brief Accelerometer Interrupt 1 Threshold Register
*  \code
*  Default value: 0x00
*  7 0
*  6 THS6-THS0 Interrupt 1 threshold.
* \endcode
*/
#define L3G_INT1_THS_REG_ADDR 0x32

/**
*  \brief Acceleroemter INT1_DURATION Register
*  \code
*  Default value: 0x00
*  7 0
*  6 D6-D0 Duration value. (Duration  steps and maximum values depend on the ODR chosen)
*   \endcode
*/
#define L3G_INT1_DURATION_REG_ADDR 0x33


/**
*  \brief INT2_CFG Register Configuration register for Interrupt 2 source.
*  \code
*  Read/write
*  Default value: 0x00
*  7 AOI: AND/OR combination of Interrupt events. See table below
*  6 6D:  6 direction detection function enable. See table below
*  5 ZHIE:  Enable interrupt generation on Z high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  4 ZLIE:  Enable interrupt generation on Z low event. 0: disable interrupt request;  1: enable interrupt request on measured accel. value lower than preset threshold
*  3 YHIE:  Enable interrupt generation on Y high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  2 YLIE:  Enable interrupt generation on Y low event. 0: disable interrupt request;  1: enable interrupt request on measured accel. value lower than preset threshold
*  1 XHIE:  Enable interrupt generation on X high event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value higher than preset threshold
*  0 XLIE:  Enable interrupt generation on X low event. 0: disable interrupt request; 1: enable interrupt request on measured accel. value lower than preset threshold
*
*             AOI     |   6D         | Interrupt mode
*        --------------------------------------------------------
*              0      |       0      | OR combination of interrupt events
*              0      |       1      | 6 direction movement recognition
*              1      |       0      | AND combination of interrupt events
*              1      |       1      |  6 direction position recognition
* \endcode
*/
#define L3G_INT2_CFG_REG_ADDR 0x34

/**
* \brief INT2_SCR Register Interrupt 2 source register.
*  \code
*  Read only register.
*  Reading at this address clears INT2_SRC IA bit (and the interrupt signal on INT 2 pin) and
*  allows the refreshment of data in the INT2_SRC register if the latched option was chosen.
*  Read
*  Default value: 0x00
*  7 0
*  6 IA : Interrupt active. 0: no interrupt has been generated; 1: one or more interrupts have been generated
*  5 ZH:  Z high. 0: no interrupt, 1: Z High event has occurred
*  4 ZL:  Z low. 0: no interrupt; 1: Z Low event has occurred
*  3 YH:  Y high. 0: no interrupt, 1: Y High event has occurred
*  2 YL:  Y low. 0: no interrupt; 1: Y Low event has occurred
*  1 YH:  X high. 0: no interrupt, 1: X High event has occurred
*  0 YL:  X low. 0: no interrupt; 1: X Low event has occurred
* \endcode
*/
#define L3G_INT2_SCR_REG_ADDR 0x35

/**
*  \brief Accelerometer Interrupt 2 Threshold Register
*  \code
*  Default value: 0x00
*  7 0
*  6 THS6-THS0 Interrupt 2 threshold.
*  \endcode
*/
#define L3G_INT2_THS_REG_ADDR 0x36

/**
*  \brief Acceromter INT2_DURATION Register
*  \code
*  Default value: 0x00
*  7 0
*  6 D6-D0 Duration value. (Duration  steps and maximum values depend on the ODR chosen)
*  \endcode
*/
#define L3G_INT2_DURATION_REG_ADDR 0x37

/**
  * @}
  */ /* end of group Gyro_Register_Mapping */


/**
* @brief Gyro Init structure definition
*/

typedef struct
{

  u8 Power_Mode;  /*!<  Low power mode selection (see table 19 datasheet) */
  u8 ODR; /*!< Output Data Rate */
  u8 Axes_Enable;    /*!< Axes Enable */
  u8 FS;     /*!< Full Scale */
  u8 Data_Update;  /*!< Data Update mode : Continuos update or data don`t change until MSB and LSB nex reading */
  u8 Endianess;   /*!< Endianess */
}L3G_ConfigTypeDef;



/**
  * @brief Accelerometer  Filter Init structure definition
  */


typedef struct
{
  u8 HPF_Enable; /*!< HPF enable*/
  u8 HPF_Mode;  /*!<HPF MODE: Normal mode or Reference signal for filtering*/
  u8 HPF_Reference;     /*!< Reference value for filtering*/
  u8 HPF_Frequency;     /*!< HPF_frequency ft=ODR/6*HPc  HPc=8,16,32,64*/
}L3G_Filter_ConfigTypeDef;


/**
 * @}
 */ /* end of group Accelerometer */

/**
 * @addtogroup Magnetometer
 * @{
 */

/**
  *@defgroup Magnetometer_Register_Mapping
  *@{
*/

/**
  *\brief Magnetometer I2C Slave Address
*/


void L3G_Config(void);
void L3G4200_I2C_Init(void);
void L3G4200_I2C_ByteWrite(u8 slAddr, u8* pBuffer, u8 WriteAddr);
void L3G4200_I2C_BufferRead(u8 slAddr,u8* pBuffer, u8 ReadAddr, u16 NumByteToRead);
void L3G4200_Config(L3G_ConfigTypeDef *L3G_Config_Struct);
void L3G4200_Filter_Config(L3G_Filter_ConfigTypeDef *L3G_Filter_Config_Struct);
void L3G4200_Lowpower_Cmd(u8 LowPowerMode);
void L3G4200_FullScale_Cmd(u8 FS_value);
void L3G4200_DataRate_Cmd(u8 DataRateValue);
void L3G4200_Reboot_Cmd(void);
void L3G4200_Read_OutReg(u8* out);
void L3G4200_Read_RawData(s16* out);
void L3G4200_Read_Acc(s16* out);
void L3G4200_DRDY_Config(void);

/**
 * @} 
 */  /* end of group LSM303DLH */

#ifdef __cplusplus
}
#endif

#endif /* __LSM303DLH_H */

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

