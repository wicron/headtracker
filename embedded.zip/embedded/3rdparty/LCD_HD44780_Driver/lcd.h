#ifndef LCD_H_
#define LCD_H_

#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "hd44780.h"
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

void Init_lcd(void);
void test(void);
void Lcd_write_string(char *STRING);

#ifdef __cplusplus
}
#endif

#endif /* HC44780_H_ */
