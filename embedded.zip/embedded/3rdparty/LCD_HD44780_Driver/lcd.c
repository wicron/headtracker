#include "lcd.h"
#include "delay.h"
u32 del;

void Init_lcd()
{
        Init_pin_out();

        delay_ms(10);
        Lcd_write_cmd(Function_set);
        delay_ms(10);

        Lcd_write_cmd(Display_on_off_control);
        delay_ms(10);

        Lcd_write_cmd(Display_clear);
        delay_ms(10);

    Lcd_write_cmd(Entry_mode_set);

}

void test(void)
{
	    delay_ms(100);
        SystemInit();
        Init_lcd();
        Lcd_clear();
        Lcd_goto(0,0);
        Lcd_write_string("WH1602B");
        Lcd_goto(1,0);
        Lcd_write_string("Test.");

    while (1)
    {

    }
}

void Lcd_write_string (char *STRING)
{
    while (*STRING) {Lcd_write_data (*STRING); STRING++;}
}

