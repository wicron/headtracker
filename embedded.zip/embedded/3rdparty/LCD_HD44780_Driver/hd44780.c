#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "hd44780.h"
#include "delay.h"
u32 del;



void Lcd_goto(uc8 x, uc8 y)
{
        int str=0;
        if (x == 0)
        {
                switch (y)
                {
                case 0:  str = 0x80; break;
                case 1:  str = 0x81; break;
                case 2:  str = 0x82; break;
                case 3:  str = 0x83; break;
                case 4:  str = 0x84; break;
                case 5:  str = 0x85; break;
                case 6:  str = 0x86; break;
                case 7:  str = 0x87; break;
                case 8:  str = 0x88; break;
                case 9:  str = 0x89; break;
                case 10: str = 0x8A; break;
                case 11: str = 0x8B; break;
                case 12: str = 0x8C; break;
                case 13: str = 0x8D; break;
                case 14: str = 0x8E; break;
                case 15: str = 0x8F; break;
                }

        }
        if (x==1)
        {
                switch (y)
                {
                case 0:  str = 0xC0; break;
                case 1:  str = 0xC1; break;
                case 2:  str = 0xC2; break;
                case 3:  str = 0xC3; break;
                case 4:  str = 0xC4; break;
                case 5:  str = 0xC5; break;
                case 6:  str = 0xC6; break;
                case 7:  str = 0xC7; break;
                case 8:  str = 0xC8; break;
                case 9:  str = 0xC9; break;
                case 10: str = 0xCA; break;
                case 11: str = 0xCB; break;
                case 12: str = 0xCC; break;
                case 13: str = 0xCD; break;
                case 14: str = 0xCE; break;
                case 15: str = 0xCF; break;
                }
        }

        Lcd_write_cmd(str);

}


void Init_pin_out()
{
        RCC_APB2PeriphClockCmd(init_port, ENABLE);
        GPIO_InitTypeDef init_pin;
        init_pin.GPIO_Pin  = pin_e | pin_rs | pin_rw | pin_d7 | pin_d6 | pin_d5 | pin_d4;
        init_pin.GPIO_Mode = GPIO_Mode_Out_PP;
        init_pin.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init (port, &init_pin);
}
void Init_pin_in()
{
        RCC_APB2PeriphClockCmd(init_port, ENABLE);
        GPIO_InitTypeDef init_pin;
        init_pin.GPIO_Pin  =  pin_d7 | pin_d6 | pin_d5 | pin_d4 ;
        init_pin.GPIO_Mode = GPIO_Mode_IPD;
        init_pin.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_Init (port, &init_pin);
}

void Lcd_write_cmd(uc8 cmd )
{
        Init_pin_out();
        delay_ms(50);
        rs_0;
        GPIO_Write(port,((cmd>>4)<<lcd_shift)); // ������� �������
        e_1;
        delay_ms(1);
        e_0;
        GPIO_Write(port,(0x00)<<lcd_shift);
        GPIO_Write(port,((cmd&0x0F)<<lcd_shift));// ������� �������
        del=10; while (del--){}
        e_1;
        del=10; while (del--){}
        e_0;rs_0;rw_0;
}

void Lcd_write_data(uint8_t data)
{
        Init_pin_out();
        GPIO_Write(port,((data>>4)<<lcd_shift)); // ������� �������
        e_1;rs_1;
        delay_ms(10);
        e_0;
        GPIO_Write(port,(0x00)<<lcd_shift);
        GPIO_Write(port,((data&0x0F)<<lcd_shift));// ������� �������
        delay_ms(10);
        e_1;rs_1;
        delay_ms(10);
        e_0;rs_0;rw_0;
        GPIO_Write(port,(0x00)<<lcd_shift);
}







void Lcd_clear()
{
        Lcd_write_cmd(Display_clear);
}

void Return_home()
{
        Lcd_write_cmd(0b0000001);
}
