/*
 * gui.c
 *
 *  Created on: 27.05.2012
 *      Author: delphi
 */

#include "gui.h"
#include <stdint.h>
#include <stdio.h>
#include "lcd.h"
#include <string.h>
#include <stdlib.h>
#include "stm32f10x.h"
#include "RTC.h"
#include "state/state.h"
#include "delay.h"
#include "stm32f10x_iwdg.h"
#include "hint.h"
#include "ins_algorithm.h"
#include "PPM.h"
#include "calibrate_magn.h"
#include "state/measurment.h"

#define NUM_SYMBOLS  8u

#define intButton1
#define intButton2

#define lineButton1
#define lineButton2

#define portButton1
#define portButton2

enum {
    GUI_IS_UPDATED,
    GUI_NEEDS_UPDATE,
    NUMBER_NEEDS_UPDATE
} GuiState;

typedef enum {
    number=0,
    yesNo=1,
    position,
    dataNeedsSaving,
    calibrationNeeded
} typeData;

typedef enum {
    notEnteredToMenu=0,
    enteredToMenu=1
} flagMenu;

flagMenu menu = notEnteredToMenu;

volatile typedef struct {
    char string1[NUM_SYMBOLS];
    char string2[NUM_SYMBOLS];
    uint16_t * parameter;
    uint16_t counter;
    typeData  data;
    uint16_t limitMin;
    uint16_t limitMax;
}guiStruct;

uint16_t _dummy; // This variable is used to write here unused data.

#define NUM_STATES  22u
volatile guiStruct _gui[NUM_STATES]= {
    {"Channel",  "Pitch ",  &_headTrackerParameters.d.pitchChannel,    0, number, 1, 8 },
    {"Channel",  "Jaw ",    &_headTrackerParameters.d.yawChannel,      0, number, 1, 8 },
    {"Channel",  "Roll ",   &_headTrackerParameters.d.rollChannel,     0, number, 1, 8 },
    {"Position",  "",       &_headTrackerParameters.d.position,        0, position, FOREHEAD, END_POSITION -1 },
    {"Positive", "PPM ",    &_headTrackerParameters.d.dir,             0, yesNo , 0, 65535  },
    {"Pitch",    "Max ",    &_headTrackerParameters.d.pitchLimitMax,   0, number, 0, 90  },
    {"Pitch",    "Min ",    &_headTrackerParameters.d.pitchLimitMin,   0, number, 0, 90  },
    {"Jaw",      "Max ",    &_headTrackerParameters.d.jawLimitMax,     0, number, 0, 90  },
    {"Jaw",      "Min ",    &_headTrackerParameters.d.jawLimitMin,     0, number, 0, 90  },
    {"Roll",     "Max ",    &_headTrackerParameters.d.rollLimitMax,    0, number, 0, 90  },
    {"Roll",     "Min ",    &_headTrackerParameters.d.rollLimitMin,    0, number, 0, 90  },
    {"Pitch",    "Rate%",   &_headTrackerParameters.d.pitchRate,       0, number, 0, 500  },
    {"Jaw",      "Rate%",   &_headTrackerParameters.d.jawRate,         0, number, 0, 500  },
    {"Roll",     "Rate%",   &_headTrackerParameters.d.rollRate,        0, number, 0, 500  },
    {"Positive", "Pitch? ", &_headTrackerParameters.d.pitchDir,        0, yesNo, 0, 65535  },
    {"Positive", "Jaw? ",   &_headTrackerParameters.d.jawDir,          0, yesNo, 0, 65535  },
    {"Positive", "Roll?",   &_headTrackerParameters.d.rollDir,        0, yesNo, 0, 65535  },
    {"Mode",     "Mix ",    &_headTrackerParameters.d.mode,            0, yesNo , 0, 65535  },
    {"Start",    "Time ",   &_headTrackerParameters.d.startTimer,      0, yesNo , 0, 65535  },
    {"Enter",    "Time ",   &_headTrackerParameters.d.time,            0, number, 0, 100  },
    {"Data is ", "saved ",  &_dummy,                              0, dataNeedsSaving, 0, 65535  },
    {"Calibr.", "Press up", &_dummy,                     0, calibrationNeeded, 0, 65535}
};

volatile uint16_t _stateCounter=NUM_STATES-1;
volatile uint8_t _guiUpdateState=GUI_IS_UPDATED;
typedef enum  {high,low} pressState;
uint32_t pressTime;

pressState buttonState=low;

void initInterrupts(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    EXTI->IMR |= EXTI_IMR_MR8; // Line 8            (GPIOA)
    EXTI->FTSR |= EXTI_FTSR_TR8; // falling edge


    EXTI->IMR |= EXTI_IMR_MR7; // Line 7            (GPIOA)
    EXTI->FTSR |= EXTI_FTSR_TR7; // falling edge
    EXTI->RTSR |= EXTI_RTSR_TR7; // Rising edge

    NVIC_EnableIRQ(EXTI9_5_IRQn);
    NVIC_SetPriority (EXTI9_5_IRQn, 3);

}

void initGUI()
{
    // Init_lcd();
    Lcd_clear();
    Lcd_goto(0,0);
    Lcd_write_string("  Head  ");
    Lcd_goto(1,0);
    Lcd_write_string("Tracker!");
    delay_ms(1000);
    initInterrupts();
}

typedef void (*handler)(char[] ,uint16_t *,uint16_t *);
typedef void (*handlerVoid)(void);


#define BIG_BOUNCE_PERIOD (0.3)

void pressButton2(void)
{
    if(_guiUpdateState!=GUI_IS_UPDATED)
        return;

    if (GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_7)) buttonState=high; else buttonState=low;
    if (buttonState==high)
    {
        pressTime=RTC_GetCounter()-pressTime;
        if ((pressTime*TIME_SCALE)>2) menu=enteredToMenu;
    }

    if (menu==notEnteredToMenu)  {pressTime=RTC_GetCounter();clearAngles();} else
    {

        *_gui[_stateCounter].parameter=_gui[_stateCounter].counter;
        _stateCounter=(_stateCounter+1)%(NUM_STATES);
        _gui[_stateCounter].counter=*_gui[_stateCounter].parameter;
        _updatedReports |= (1<<PARAMETERS_REPORT_ID);
        _guiUpdateState = GUI_NEEDS_UPDATE;

        if ((!GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_8))&&(!GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_7)))
        {
            *_gui[_stateCounter].parameter=_gui[_stateCounter].counter;
            _stateCounter=NUM_STATES-1;
            _guiUpdateState=GUI_NEEDS_UPDATE;
        }

    }
}


#define SMALL_BOUNCE_PERIOD (0.1)
void pressButton1(void)
{
    if (menu==notEnteredToMenu)  {clearAngles();return;}

    if(_guiUpdateState!=GUI_IS_UPDATED)
        return;


    if (GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_8)) buttonState=high; else buttonState=low;
    if (buttonState==high)
    {
        pressTime=RTC_GetCounter()-pressTime;
        if ((pressTime*TIME_SCALE)<2)
        {
            clearAngles();
            return;
        }
    }  else

    {
        pressTime=RTC_GetCounter();



        (_gui[_stateCounter].counter+=1);
        if (_gui[_stateCounter].counter>_gui[_stateCounter].limitMax)
            _gui[_stateCounter].counter=_gui[_stateCounter].limitMin;
        _guiUpdateState = NUMBER_NEEDS_UPDATE;
    }
}

void calibrate()
{
    IWDG_ReloadCounter();
    _headTrackerParameters.d.magnOffsetX = 0;
    _headTrackerParameters.d.magnOffsetY = 0;
    _headTrackerParameters.d.magnOffsetZ = 0;
    _headTrackerParameters.d.magnScaleX = ANGLE_SCALE;
    _headTrackerParameters.d.magnScaleY = ANGLE_SCALE;
    _headTrackerParameters.d.magnScaleZ = ANGLE_SCALE;

    delay_ms(1000);

    MagnEquation *eq = allocateEquation(100);
    for(;;){
        getDataFromMagnet();
        delay_ms(80);
        float magn[3];
        for(int i=0; i<3; ++i)
            magn[i] = _measurments.magn[i];
        if(addRow(eq, magn)==0)
            break;
        IWDG_ReloadCounter();
    }
    solve(eq);
    _headTrackerParameters.d.magnOffsetX = eq->offset[0]*MAGN_OFFSET_SCALE;
    _headTrackerParameters.d.magnOffsetY = eq->offset[1]*MAGN_OFFSET_SCALE;
    _headTrackerParameters.d.magnOffsetZ = eq->offset[2]*MAGN_OFFSET_SCALE;
    _headTrackerParameters.d.magnScaleX = eq->scale[0]*ANGLE_SCALE;
    _headTrackerParameters.d.magnScaleY = eq->scale[1]*ANGLE_SCALE;
    _headTrackerParameters.d.magnScaleZ = eq->scale[2]*ANGLE_SCALE;

    deleteEquation(eq);

    saveParametersToEEPROM();
}

void showCalibrationResults()
{
    IWDG_ReloadCounter();
    Lcd_clear();
    Lcd_goto(0, 0);
    char text[9];
    sprintf (text, "x %d", (int)(_headTrackerParameters.d.magnOffsetX/MAGN_OFFSET_SCALE));
    Lcd_write_string(text);
    Lcd_goto(1, 0);
    sprintf (text, "y %d",(int)(_headTrackerParameters.d.magnOffsetY/MAGN_OFFSET_SCALE));
    Lcd_write_string(text);

    IWDG_ReloadCounter();
    delay_ms(1000);

    Lcd_clear();
    Lcd_goto(0, 0);
    sprintf (text, "z %d",(int)(_headTrackerParameters.d.magnOffsetZ/MAGN_OFFSET_SCALE));
    Lcd_write_string(text);

    IWDG_ReloadCounter();
    delay_ms(1000);

    Lcd_clear();
    Lcd_goto(0, 0);
    sprintf (text, "sy %.2f",_headTrackerParameters.d.magnScaleY/ANGLE_SCALE);
    Lcd_write_string(text);
    Lcd_goto(1, 0);
    sprintf (text, "sz %.2f",_headTrackerParameters.d.magnScaleZ/ANGLE_SCALE);
    Lcd_write_string(text);

    IWDG_ReloadCounter();
    delay_ms(1000);
    IWDG_ReloadCounter();
}

void handlerGuiState(uint16_t counter, uint16_t state)
{
    if(_guiUpdateState==GUI_IS_UPDATED)
        return;

    char text2[NUM_SYMBOLS];
    sprintf (text2, "%u",(unsigned int)(_gui[state].counter));
    IWDG_ReloadCounter();

    if(_guiUpdateState==GUI_NEEDS_UPDATE){
        Lcd_clear();
        Lcd_goto(0,0);
        Lcd_write_string((char*)_gui[state].string1);
        Lcd_goto(1,0);
        Lcd_write_string((char*)_gui[state].string2);
    }else
        Lcd_goto(1, strlen((const char*)_gui[state].string2));

    uint8_t curPosition = strlen((const char*)_gui[state].string2);

    _guiUpdateState = GUI_IS_UPDATED;

    char buffer[9]="";
    switch(_gui[state].data)
    {
    case number:
        Lcd_write_string(text2);
        break;

    case yesNo:
        _gui[state].counter=(_gui[state].counter)%2;
        if (_gui[state].counter)
            strcpy(buffer, "YES");
        else
            strcpy(buffer, "NO");
        break;

    case dataNeedsSaving:
        saveParametersToEEPROM();
        delay_ms(500);
        break;

    case position:
        Lcd_goto(1,0);
        switch(_gui[state].counter)
        {
        case FOREHEAD:
            strcpy(buffer, "FORWARD");
            break;
        case LEFT_TEMPLE:
            strcpy(buffer, "LEFT");
            break;
        case RIGHT_TEMPLE:
            strcpy(buffer, "RIGHT");
            break;
        case NAPE:
            strcpy(buffer, "BACK");
            break;
        case TOP_OF_HEAD:
            strcpy(buffer, "UP");
            break;
        default:
            strcpy(buffer, "Err");
        }
        break;

    case calibrationNeeded:
        if(_gui[state].counter)
        {
            _gui[state].counter = 0;

            Lcd_clear();
            Lcd_goto(0,0);
            Lcd_write_string("Rotate");
            calibrate();

            Lcd_goto(0, 0);
            Lcd_write_string("Finished");

            showCalibrationResults();

            _guiUpdateState=GUI_NEEDS_UPDATE;
        }
        break;

    }

    for(uint8_t i=strlen(buffer); i<8-curPosition; ++i)
        buffer[i]=' ';
    buffer[8]=0;

    Lcd_write_string(buffer);
}

void refreshGui(void)
{
    handlerGuiState(_gui[_stateCounter].counter,_stateCounter);
}


void   EXTI9_5_IRQHandler(void)        //; EXTI Line 9..5
{
    NVIC_DisableIRQ(EXTI9_5_IRQn);
    if (EXTI_GetITStatus(EXTI_Line7) != RESET) pressButton2();
    if (EXTI_GetITStatus(EXTI_Line8) != RESET) pressButton1();
    if (EXTI_GetITStatus(EXTI_Line5) != RESET) getDataFromLSM303DLHC();
    EXTI_ClearITPendingBit(EXTI_Line5);
    EXTI_ClearITPendingBit(EXTI_Line7);
    EXTI_ClearITPendingBit(EXTI_Line8);
    NVIC_EnableIRQ(EXTI9_5_IRQn);
    return;
}



