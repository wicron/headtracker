/*
 * bootloader.c
 *
 *  Created on: 22.11.2012
 *      Author: delphi
 */
#include "bootloader.h"
#include "stm32f10x.h"
#define FW_START 0x08002000
void (*systemMemBootJump)(void);


void hardEnterSoftwareDFUbootloader(void)
{

static const uint16_t launch_fw_code[] =
{
        0xF850, 0xDB04, /* LDR.W SP, [R0], #4   */
        0x6800,         /* LDR.W R0, [R0]       */
        0x4700,         /* BX R0                */
};

((void (*)(int))(1+(int)launch_fw_code))(FW_START);
}

void safeEnterHardwareDFUbootloader(void)
{
 systemMemBootJump=(void (*)(void))(*((u32*) 0x1FFF0004));
 RCC_DeInit();
 SysTick->CTRL=0;
 SysTick->LOAD=0;
 SysTick->VAL=0;
 __disable_irq();
 __set_MSP(0x20001000);
 systemMemBootJump();
}


void systemDefault(void)
{

}
