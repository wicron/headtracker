/*
 * hint.c
 *
 *  Created on: 07.08.2012
 *      Author: DELPHI
 */

#include "hint.h"
#include "stm32f10x.h"
#include "lcd.h"
#include "delay.h"
#include "PPM.h"
#include "state/state.h"
#include "state/measurment.h"
#include "LSM303DLHC.h"
#include "L3G4200.h"
#include "led.h"

typedef enum {needUpdate=0,updated=1} updateData;
updateData accDataStatus=needUpdate;
updateData gyroDataStatus=needUpdate;
updateData magnetDataStatus=needUpdate;

#define PARAMETERS_EEPROM_ADDRESS (0)

void initState(void)
{
    //! @todo initialize parameters with default values

    _headAngle.roll=0;
    _headAngle.jaw=0;
    _headAngle.pitch=0;
     loadParametersFromEEPROM();
}

void saveParametersToEEPROM(void)
{
    calcCrc(&_headTrackerParameters);
    saveStructToEEPROM((uint16_t*)&_headTrackerParameters, sizeof(HeadTrackerParameters),
                       PARAMETERS_EEPROM_ADDRESS);
}

void resetParams()
{
    setDefault(&_headTrackerParameters);
    saveParametersToEEPROM();

    Lcd_clear();
    Lcd_goto(0,0);
    Lcd_write_string("Reset to");
    Lcd_goto(1,0);
    Lcd_write_string("Default");
    delay_ms(500);
}

void loadParametersFromEEPROM(void)
{
    loadStructFromEEPROM((uint16_t*)&_headTrackerParameters, sizeof(HeadTrackerParameters),
                       PARAMETERS_EEPROM_ADDRESS);
    uint16_t oldCrc = _headTrackerParameters.crc;
    calcCrc(&_headTrackerParameters);
    if(oldCrc != _headTrackerParameters.crc){
        resetParams();
    }
}

void saveStructToEEPROM( uint16_t* data, uint16_t dataSize, uint16_t firstVirtualAddress)
{
    //! @todo Add loading here.
    FLASH_Unlock();
    EE_Init();

    for(uint16_t* lastAddress = data + dataSize/2 + dataSize%2;
        data < lastAddress ; ++data,  ++firstVirtualAddress)
        EE_WriteVariable(firstVirtualAddress, *data);
    FLASH_Lock();
}

void loadStructFromEEPROM( uint16_t* data, uint16_t dataSize, uint16_t firstVirtualAddress)
{
    //! @todo Add loading here.
    FLASH_Unlock();
    EE_Init();

    for(uint16_t* lastAddress = data + dataSize/2;
        data < lastAddress ; ++data,  ++firstVirtualAddress)
        EE_ReadVariable(firstVirtualAddress, data);

    if(dataSize%2){
        uint16_t temp;
        EE_ReadVariable(firstVirtualAddress, &temp);
        uint8_t *lastByte = (uint8_t*)data;
        *lastByte = temp & 0xFF;
    }

    FLASH_Lock();
}

/*-----------------------------------------------------------*/
void switchToHSI(void)
{
	 RCC_HSICmd (ENABLE);
	 RCC_PLLConfig (RCC_PLLSource_HSI_Div2 , RCC_PLLMul_16);
	 RCC_PLLCmd (ENABLE);
	 FLASH->ACR |= FLASH_ACR_PRFTBE;

	    /* Flash 2 wait state */
	    FLASH->ACR &= (uint32_t)((uint32_t)~FLASH_ACR_LATENCY);
	    FLASH->ACR |= (uint32_t)FLASH_ACR_LATENCY_2;


	    /* HCLK = SYSCLK */
	    RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;

	    /* PCLK2 = HCLK */
	    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE2_DIV1;

	    /* PCLK1 = HCLK */
	    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE1_DIV2;
	    // �������� PLL
	    RCC->CR |= RCC_CR_PLLON;
	   	      // �������, ���� PLL �������� ��� ����������
	    while((RCC->CR & RCC_CR_PLLRDY) == 0) {}
	   	      // �������� PLL ��� �������� ��������� �������
	    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
	    RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;
	   	      // �������, ���� PLL ��������� ��� �������� ��������� �������
	    while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)0x08) {}

}


void badQuartzHandler(void)
{
	 	 	 switchToHSI();
	 	 	 SystemCoreClockUpdate();
	 	 	 initDelay();
	         delay_ms(100);
		     Init_lcd();
		     delay_ms(100);
		     Lcd_clear();
		     Lcd_goto(0,0);
		     Lcd_write_string("Ext Qurz");
		     Lcd_goto(1,0);
		     Lcd_write_string("Error");
		     delay_ms(300);
		     Lcd_clear();
		     Lcd_goto(0,0);
		     Lcd_write_string("Switch");
		     Lcd_goto(1,0);
		     Lcd_write_string("to HSI");
		     delay_ms(300);

}

void badQuartzExeption(void)
{

	    RCC->CR|=RCC_CR_CSSON; // ��������� ������ ������� ������ HSE.
}

void IWDG_INIT(void)
{
	__IO uint32_t LsiFreq = 40000;
	 /* IWDG timeout equal to 250 ms (the timeout may varies due to LSI frequency
	     dispersion) */
	  /* Enable write access to IWDG_PR and IWDG_RLR registers */
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);

   /* IWDG counter clock: LSI/32 */
  IWDG_SetPrescaler(IWDG_Prescaler_256);

	  // Set counter reload value to obtain 6.4ms IWDG TimeOut.

  IWDG_SetReload(LsiFreq/32);

  /* Reload IWDG counter */
  IWDG_ReloadCounter();

   /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
  IWDG_Enable();
}


void getDataFromSensors(void)
{
 // Measure data in local coordinates.

     if (accDataStatus==needUpdate) {getDataFromAcc();accDataStatus=updated; _updatedReports |= (1<<MEASURMENT_REPORT_ID);}

     if (magnetDataStatus==needUpdate) {getDataFromMagnet();magnetDataStatus=updated; _updatedReports |= (1<<MEASURMENT_REPORT_ID);}

     /** @warning This works slow but asyncronously it doesn't work at all.
      * So bad work is better than no work */
     getDataFromGyro();
     gyroDataStatus=updated;
     _updatedReports |= (1<<MEASURMENT_REPORT_ID);

    _updatedReports |= (1<<MEASURMENT_REPORT_ID);
}

/** @warning This values works for my board(Pavel Kartavyy)
  I cannot garanty that they will work for any other board.
  If this values are board dependent than you should write a calibration on C.
  Example of calibration on python you can find in head_tracker/python folder*/
void calibrateMagnMeasurments(s16 *measurments){
    measurments[0] = measurments[0] - _headTrackerParameters.d.magnOffsetX/MAGN_OFFSET_SCALE;

    measurments[1] = (measurments[1] - _headTrackerParameters.d.magnOffsetY/MAGN_OFFSET_SCALE)/(_headTrackerParameters.d.magnScaleY/ANGLE_SCALE);
    measurments[2] = (measurments[2] - _headTrackerParameters.d.magnOffsetZ/MAGN_OFFSET_SCALE)/(_headTrackerParameters.d.magnScaleZ/ANGLE_SCALE);
}

void getDataFromMagnet(void)
{
    s16 out[3];
    LSM303DLH_Magn_Read_Magn(out);


    _measurments.magn[0]= -out[2];
    _measurments.magn[1]= out[1];
    _measurments.magn[2]= out[0];

    calibrateMagnMeasurments(_measurments.magn);
}

void getDataFromGyro(void)
{
	 s16 out[3];
	  L3G4200_Read_Acc(out);
	        _measurments.gyro[0]=-out[0];
	        _measurments.gyro[1]= -out[2];
	        _measurments.gyro[2]=-out[1];

}

void getDataFromAcc(void)
{
	 s16 out[3];
    LSM303DLH_Acc_Read_Acc(out);
        _measurments.accel[0]=out[1];
        _measurments.accel[1]=-out[2];
        _measurments.accel[2]=-out[0];
}

void getDataFromLSM303DLHC(void)
{
      accDataStatus=needUpdate;
   //   getDataFromL3G4200(); // please, don't touch, this is a hack. Because magnet and acc are slower than gyro
	 magnetDataStatus=needUpdate;
}


void getDataFromL3G4200(void)
{
      gyroDataStatus=needUpdate;

}

void   EXTI2_IRQHandler(void)
{
	NVIC_DisableIRQ(EXTI2_IRQn);
	EXTI_ClearITPendingBit(EXTI_Line2);
	//getDataFromGyro();
    getDataFromL3G4200();
    //for (int i=0;i<10000;++i){;}
    //blinkLed1();
    NVIC_EnableIRQ(EXTI2_IRQn);
    return;
}

void bootButtonHandler()
{

    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    if ((!(GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_7)))&&(!(GPIO_ReadInputDataBit(GPIOA,  GPIO_Pin_8))))
    {
        resetParams();
    }
}
