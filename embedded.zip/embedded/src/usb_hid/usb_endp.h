#ifndef _USB_ENDP_H_
#define _USB_ENDP_H_

/** @brief write data to ENDP1_In.
*** Size of data must be less then EP1_WMAX_PACKET_SIZE -1 bytes **/
int usb_hid_write(uint8_t *data, uint8_t size, uint8_t reportId);

//! @brief return true if usb transfer is completed.
int usb_transfer_completed();
#endif /*_USB_ENDP_H_*/
