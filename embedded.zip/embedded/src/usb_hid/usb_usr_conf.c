#include "usb_usr_conf.h"
#include "usb_endp.h"

#include "hint.h"

uint8_t _parametersNeedToBeSaved = 0;
int usb_process_data(uint8_t *data, uint8_t size, uint8_t reportId)
{
    switch(reportId)
    {
    case PARAMETERS_REPORT_ID:
        if (checkCrc((HeadTrackerParameters*)data))
        {
            __builtin_memcpy(&_headTrackerParameters, data, size);
            _updatedReports |= (1<<PARAMETERS_REPORT_ID);
            _parametersNeedToBeSaved = 1;
        }
        break;
    default:
        return -1;
    }

    return 0;
}

//! @brief Enable to send HeadTrackerParameters each n call of this function.
void enable2sendParameters()
{
    int n = 10;
    static int d = 0;
    d = (d+1)%n;
    if(!d)
        _updatedReports |= (1<<PARAMETERS_REPORT_ID);
}

void usb_send_data()
{
    if(usb_transfer_completed())
        return;
    // Try to send each report while some piece of data would not be transmited.
    static uint8_t key = PARAMETERS_REPORT_ID;
    uint8_t attempts = END_REPORT_ID;
    uint8_t transmited = 0;

    while(attempts > 0 && !transmited)
    {
        --attempts;
        key = (key + 1)%END_REPORT_ID;
        enable2sendParameters();
        if( (_updatedReports & (1<<key)) )
        {
            transmited = 1;
            switch(key)
            {
            case MEASURMENT_REPORT_ID:
                usb_hid_write((uint8_t*)&_measurments, sizeof(HeadTrackerMeasurment), MEASURMENT_REPORT_ID);
                break;
            case PARAMETERS_REPORT_ID:
                calcCrc(&_headTrackerParameters);
                usb_hid_write((uint8_t*)&_headTrackerParameters, sizeof(HeadTrackerParameters), PARAMETERS_REPORT_ID);
                break;
            case ANGLE_REPORT_ID:
                usb_hid_write((uint8_t*)&_headAngle, sizeof(HeadAngle), ANGLE_REPORT_ID);
                break;
            default:
                transmited = 0;
            }
            _updatedReports &= ~(1<<key);
        }
    }

    if(_parametersNeedToBeSaved)
        saveParametersToEEPROM();
}
