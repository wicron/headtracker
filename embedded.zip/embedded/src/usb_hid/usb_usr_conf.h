#ifndef _USB_USR_CONF_H_
#define _USB_USR_CONF_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include "state/state.h"
#include "state/measurment.h"


/** @file realizes functions and defines which are different for diferent devices.
  * This should make development of new device with usb hid to be easy process */

// Hid serial is a string which help to recognize different devices with similar ProductId and VendorId.
// Serial must be 16 bytes.
// Example:
// #define HID_STRING_SERIAL 'H', 0, 'T', 0, 'r', 0, 'a', 0, 'c', 0, 'k', 0, 'e', 0,'r', 0
#define HID_STRING_SERIAL 'H', 0, 'T', 0, 'r', 0, 'a', 0, 'c', 0, 'k', 0, 'e', 0,'r', 0

// Structure must be packed. You can identify structures using report id.
// Max length of structure is 63 bytes. Structure must be packed.
// If you want to use bigger structures you need to send and receive it by parts.

// You need to define size of each report which is equal to size of structure.
// If you want to use more or less reports than edit usb_desc.h and usb_desc.c
#define REPORT_COUNT_1 sizeof(HeadTrackerParameters)
#define REPORT_COUNT_2 sizeof(HeadAngle)
#define REPORT_COUNT_3 sizeof(HeadTrackerMeasurment)

/** @brief you need to modify implementation of this function.
  * It should send data over usb according to your needs
  * and it should be called in main loop. */
void usb_send_data();

/** @brief process data, which is read from EP1_Out
  * You need to modify implementation of this function
  * which should copy data from uint8_t array to your structure.
  * The type of structure should depends on reportId
  *  @return 0 if all is ok */

int usb_process_data(uint8_t *data, uint8_t size, uint8_t reportId);


#ifdef __cplusplus
 }
#endif

#endif /* _USB_USR_CONF_H_ */
