/******************** (C) COPYRIGHT 2011 STMicroelectronics ********************
* File Name          : usb_endp.c
* Author             : MCD Application Team
* Version            : V3.3.0
* Date               : 21-March-2011
* Description        : Endpoint routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#ifdef STM32L1XX_MD
#include "stm32l1xx.h"
#else
#include "stm32f10x.h"
#endif /* STM32L1XX_MD */

#include "platform_config.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "state/state.h"
#include "state/measurment.h"
#include "usb_endp.h"
#include "usb_desc.h"
#include "usb_usr_conf.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint8_t receiveBuffer[EP1_WMAX_PACKET_SIZE];
uint8_t sendBuffer[EP1_WMAX_PACKET_SIZE];

__IO uint8_t PrevXferComplete = 1;

//Device can write one of the following structures - HeadTrackerParams, HeadAngle, measurments
#define MAX(a, b) ( (a) > (b) ? (a) : (b) )

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : EP1_OUT_Callback.
* Description    : EP1 OUT Callback Routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_OUT_Callback(void)
{
  int dataSize = USB_SIL_Read(EP1_OUT, receiveBuffer);
  if(dataSize > 0)
    usb_process_data(receiveBuffer + 1, dataSize - 1, receiveBuffer[0] );

#ifndef STM32F10X_CL   
  SetEPRxStatus(ENDP1, EP_RX_VALID);
#endif /* STM32F10X_CL */
 
}

/*******************************************************************************
* Function Name  : EP1_IN_Callback.
* Description    : EP1 IN Callback Routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_IN_Callback(void)
{
  PrevXferComplete = 1;
}

int usb_transfer_completed()
{
    return PrevXferComplete ? 0 : -1;
}

int usb_hid_write(uint8_t *data, uint8_t size, uint8_t reportId)
{
    if(!PrevXferComplete)
        return -1;
    if(size >=EP1_WMAX_PACKET_SIZE - 1)
        return -1;
    sendBuffer[0]=reportId;
    __builtin_memcpy(sendBuffer+1, data, size );
    USB_SIL_Write(EP1_IN, sendBuffer, size + 1);
    SetEPTxValid(ENDP1);
    PrevXferComplete = 0;
    return 0;
}

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

