/*
 * usart.h
 *
 *  Created on: 03.06.2012
 *      Author: delphi
 */

#ifndef USART_H_
#define USART_H_

void USART1Init(void);

#endif /* USART_H_ */
