/*
 * delay.h
 *
 *  Created on: 23.07.2012
 *      Author: DELPHI
 */

#ifndef DELAY_H_
#define DELAY_H_

void delay_ms(uint16_t value);
void initDelay(void);

#endif /* DELAY_H_ */
