/*
 * test.h
 *
 *  Created on: 04.09.2012
 *      Author: DELPHI
 */

#ifndef TEST_H_
#define TEST_H_
void testLSM303DLHC_Acc(void);
void testL3G4200(void);
void testLSM303DLHC_Magn(void);
void testLSM303(void);
void testEeprom();

#endif /* TEST_H_ */
