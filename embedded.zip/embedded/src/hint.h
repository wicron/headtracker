/*
 * hint.h
 *
 *  Created on: 07.08.2012
 *      Author: DELPHI
 */

#ifndef HINT_H_
#define HINT_H_
#include "eeprom.h"
#include <stdint.h>
void switchToHSI(void);
void badQuartzHandler(void);
void badQuartzExeption(void);
/* Virtual address defined by the user: 0xFFFF value is prohibited */
extern uint16_t VirtAddVarTab[NumbOfVar];
void IWDG_INIT(void);
void initState(void);
void getDataFromSensors(void);

void saveStructToEEPROM(uint16_t* data, uint16_t dataSize, uint16_t firstVirtualAddress);
void loadStructFromEEPROM(uint16_t* data, uint16_t dataSize, uint16_t firstVirtualAddress);

void saveParametersToEEPROM();
void loadParametersFromEEPROM(void);

void getDataFromMagnet(void);
void getDataFromGyro(void);
void getDataFromAcc(void);
void getDataFromLSM303DLHC(void);
void getDataFromL3G4200(void);

void bootButtonHandler();
#endif /* HINT_H_ */
