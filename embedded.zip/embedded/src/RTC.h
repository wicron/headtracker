/*
 * RTC.h
 *
 *  Created on: 04.06.2012
 *      Author: delphi
 */

#ifndef RTC_H_
#define RTC_H_

#include "stm32f10x_rtc.h"

#define TIME_SCALE (2*30.5/1000000) // to get time in second just multiply RTC_GetCounter() to it

uint8_t RtcInit(void);
void RtcInitSafe(void);
#endif /* RTC_H_ */
