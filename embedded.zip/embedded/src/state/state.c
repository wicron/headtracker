#include "state.h"
#include "measurment.h"
#include "crc.h"
#include "ins_algorithm.h"

HeadTrackerParameters _headTrackerParameters;
HeadAngle _headAngle;
HeadTrackerMeasurment _measurments;
UpdatedReports _updatedReports = 0;

void calcCrc(HeadTrackerParameters* p)
{
    p->crc = crc16((uint8_t*)&(p->d), sizeof(HeadTrackerParametersData));
}

void setDefault(HeadTrackerParameters *p)
{
    p->d.pitchChannel=1;
    p->d.yawChannel=2;
    p->d.rollChannel=3;
    p->d.position=FOREHEAD;
    p->d.dir=positive;
    p->d.pitchLimitMax=90;
    p->d.pitchLimitMin=90;
    p->d.pitchDir=yes;
    p->d.jawLimitMax=90;
    p->d.jawLimitMin=90;
    p->d.jawDir=yes;
    p->d.rollLimitMax=90;
    p->d.rollLimitMin=90;
    p->d.rollDir=yes;
    p->d.pitchRate=100;
    p->d.jawRate=100;
    p->d.rollRate=100;
    p->d.mode=mix;
    p->d.startTimer=no;
    p->d.time=10;

    p->d.magnOffsetX = 0;
    p->d.magnOffsetY = 0;
    p->d.magnOffsetZ = 0;
    p->d.magnScaleX = ANGLE_SCALE;
    p->d.magnScaleY = ANGLE_SCALE;
    p->d.magnScaleZ = ANGLE_SCALE;
}

int checkCrc(HeadTrackerParameters* p)
{
    return p->crc == crc16((uint8_t*)&(p->d), sizeof(HeadTrackerParametersData));
}
