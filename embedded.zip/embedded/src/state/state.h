#ifndef __STATE_H_
#define __STATE_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>

#define NUM_CHANNELS 8u

enum {
    PARAMETERS_REPORT_ID=1,
    ANGLE_REPORT_ID=2,
    MEASURMENT_REPORT_ID=3,
    END_REPORT_ID
};

typedef enum {positive=1,negative=0} direction;

typedef enum {pitchAngle,jawAngle,rawAngle,noAngle} eulerAngle;  //íāęëîí, ïîâîðîō, ęðåí
typedef enum {noMix=0,mix=1} mode;
typedef enum {no=0,yes=1} answer;

#define ANGLE_SCALE (100.0)
#define MAGN_OFFSET_SCALE (0.1)
#pragma pack(push,1)
typedef struct {
    int16_t    pitch;
    int16_t    jaw;
    int16_t    roll;
    int16_t    q[4];
} HeadAngle;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct{
uint16_t    position;
uint16_t    dir;
uint16_t    mode;
uint16_t    rollChannel;
uint16_t    pitchChannel;
uint16_t    yawChannel;
uint16_t    pitchLimitMax;
uint16_t    pitchLimitMin;
uint16_t    pitchDir;
uint16_t    jawLimitMax;
uint16_t    jawLimitMin;
uint16_t    jawDir;
uint16_t    rollLimitMax;
uint16_t    rollLimitMin;
uint16_t    rollDir;
uint16_t    pitchRate; // You should multiply this value for 1.0/ANGLE_SCALE
uint16_t    jawRate; // You should multiply this value for 1.0/ANGLE_SCALE
uint16_t    rollRate; // You should multipky this value for 1.0/ANGLE_SCALE
uint16_t    startTimer;
uint16_t    time;

// You should delete magnOffset* on MAGN_OFFSET_SCALE to get real value
int16_t     magnOffsetX;
int16_t     magnOffsetY;
int16_t     magnOffsetZ;
// You should delete magnScale* on ANGLE_SCALE to get real value
uint16_t    magnScaleX;
uint16_t    magnScaleY;
uint16_t    magnScaleZ;
} HeadTrackerParametersData;
#pragma pack(pop)

#pragma pack(push,1)
typedef struct {
    HeadTrackerParametersData d;
    uint16_t    crc;
}HeadTrackerParameters;
#pragma pack(pop)

typedef uint32_t UpdatedReports;

extern HeadTrackerParameters _headTrackerParameters;
extern HeadAngle _headAngle;
extern UpdatedReports _updatedReports;

void calcCrc(HeadTrackerParameters* p);
int checkCrc(HeadTrackerParameters* p);
void setDefault(HeadTrackerParameters *p);

#ifdef __cplusplus
 }
#endif
#endif /*__STATE_H_*/
