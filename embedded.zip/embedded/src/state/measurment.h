#ifndef __MEASURMENT_H_
#define __MEASURMENT_H_

#ifdef __cplusplus
 extern "C" {
#endif

//! @todo Fill with correct scales.
#define gGravity 9.81
#define Pi (3.14159265)
#define HT_GYRO_SCALE     (Pi/180)                //   radians/second
#define HT_ACCEL_SCALE (2*gGravity/32767)   // m/s^2
#define HT_MAGN_SCALE     1               // gauss

#pragma pack(push,1)
typedef struct {
    int16_t    gyro[3];
    int16_t    accel[3];
    int16_t    magn[3];
} HeadTrackerMeasurment;
#pragma pack(pop)

extern HeadTrackerMeasurment _measurments;

#ifdef __cplusplus
 }
#endif

#endif /*__MEASURMENT_H_*/
