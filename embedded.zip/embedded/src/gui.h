/*
 * gui.h
 *
 *  Created on: 27.05.2012
 *      Author: �������������
 */

#ifndef GUI_H_
#define GUI_H_
#include <stdint.h>
void initInterrupts(void);
void initGUI(void);
void handlerGuiState(uint16_t counter,uint16_t state);
void refreshGui(void);
void pressButton1(void);
void pressButton2(void);
void initData(void);
#endif /* GUI_H_ */
