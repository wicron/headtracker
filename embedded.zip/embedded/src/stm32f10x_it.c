/**
  ******************************************************************************
  * @file    EEPROM_Emulation/src/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.1.0
  * @date    07/27/2009
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "core_cm3.h"
#include "lcd.h"
#include "hint.h"


#ifdef USB_HID
#include "usb_hid/usb_istr.h"
#endif

/** @addtogroup EEPROM_Emulation
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
	if (RCC->CIR & RCC_CIR_CSSF) RCC->CIR|=RCC_CIR_CSSC;
	 badQuartzHandler();
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("NMI");
	Lcd_goto(1,0);
	Lcd_write_string("Handler");

	//NVIC_SystemReset();
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Hard");
	Lcd_goto(1,0);
	Lcd_write_string("Fault");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string(".Error.");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Memory");
	Lcd_goto(1,0);
	Lcd_write_string("Manage");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string(".Error.");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Bus");
	Lcd_goto(1,0);
	Lcd_write_string("Fault");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Usage");
	Lcd_goto(1,0);
	Lcd_write_string("Fault");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("SVC");
	Lcd_goto(1,0);
	Lcd_write_string("Fault");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Debug");
	Lcd_goto(1,0);
	Lcd_write_string("Mon");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Critical");
	Lcd_goto(1,0);
	Lcd_write_string("Error");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("PendSV");
	Lcd_goto(1,0);
	Lcd_write_string("Handler");
	Lcd_clear();
	Lcd_goto(0,0);
	Lcd_write_string("Restart");
	Lcd_goto(1,0);
	Lcd_write_string("System");
	NVIC_SystemReset();
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
/*
void SysTick_Handler(void)
{
}
*/
/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/


/*******************************************************************************
* Function Name  : USB_LP_CAN1_RX0_IRQHandler
* Description    : This function handles USB Low Priority or CAN RX0 interrupts
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef USB_HID
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  USB_Istr();
}
#endif /* USB_HID */

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
