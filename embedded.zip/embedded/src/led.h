/*
 * led.h
 *
 *  Created on: 24.07.2012
 *      Author: Admin
 */

#ifndef LED_H_
#define LED_H_
void initLED1(void);
void initLED2(void);
void blinkLed1(void);
void blinkLed2(void);

#endif /* LED_H_ */
