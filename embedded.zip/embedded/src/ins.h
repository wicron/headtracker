/*
 * ins.h
 *
 *  Created on: 04.09.2012
 *      Author: DELPHI
 */

#ifndef INS_H_
#define INS_H_

void readInsSensors(float gyro[3], float accel[3], float magn[3]);
void ins(float *angleZ, float *angleY);
void simpleInsInit();

#endif /* INS_H_ */
