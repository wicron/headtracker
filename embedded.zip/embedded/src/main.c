/* Standard includes. */
#include "stm32f10x.h"

#include "usb_lib.h"
#include "hw_config.h"

#ifdef USB_HID
#include "usb_endp.h"
#include "usb_usr_conf.h"
#endif /* USB_HID */

#include "usart.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "lcd.h"
#include "eeprom.h"
#include "LSM303DLHC.h"
#include "L3G4200.h"
#include "gui.h"

#include "ins_algorithm.h"
#include "test.h"
#include "PPM.h"
#include "RTC.h"
#include "ins.h"
#include "delay.h"
#include "led.h"
#include "hint.h"

#include "state/state.h"
#include "state/measurment.h"
#include "bootloader.h"

ErrorStatus  HSEStartUpStatus;

FLASH_Status FlashStatus;
uint16_t VarValue = 0;

// Measure all sensors in local coordinate system
void start(void);

#if defined(USB_COM) && defined(USB_HID)
#   error "USB_HID and USB_COM cannot be defined the same time. Try to delete CMakeCache.txt"
#endif


#ifdef USB_COM
#   define dprintf(...) printf (__VA_ARGS__)
#else
#   define dprintf(...) iprintf (__VA_ARGS__)
#endif
//--------------------------------------------------------------


int main(void) {

    start();

    uint32_t startTime;
    if (_headTrackerParameters.d.startTimer==yes)
    {
    	startTime=RTC_GetCounter();
    	Lcd_clear();
        Lcd_goto(0,0);
        Lcd_write_string("Timer On");
        while (((RTC_GetCounter()-startTime)*TIME_SCALE)<_headTrackerParameters.d.time) {
            IWDG_ReloadCounter();
#ifdef USB_HID
            usb_send_data();
#endif
        }
        Lcd_goto(1,0);
        Lcd_write_string("Started");
    }

    // Ins initialization
    simpleInsInit();

    float angleZ=0;
    float angleY=0;
    while(1)
    {
        IWDG_ReloadCounter();
        refreshGui();

        IWDG_ReloadCounter();
        ins(&angleZ, &angleY);

        refreshPPM();
       //getCapture();
#ifdef USB_HID
        usb_send_data();
#endif
    }
}


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
      ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

    /* Infinite loop */
    while (1)
    {}
}
#endif



void start(void)
{

    SystemInit();
    Set_System();
    initLED1();

    IWDG_INIT();
    initDelay();

    USB_Interrupts_Config();

    Set_USBClock();
    IWDG_ReloadCounter();
    USB_Init(); // USB must be initialized in first order.
    GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_SET);
    badQuartzExeption();

    delay_ms(100);
    IWDG_ReloadCounter();
    Init_lcd();


    IWDG_ReloadCounter();

     RtcInit(); // RTC must be initialized before GUI because GUI is using RTC.

    IWDG_ReloadCounter();
    initState();

    IWDG_ReloadCounter();
    __enable_irq();

    IWDG_ReloadCounter();
    bootButtonHandler();

    IWDG_ReloadCounter();
    initGUI();

    IWDG_ReloadCounter();
    USART1Init();

    IWDG_ReloadCounter();
    initPPM();

    IWDG_ReloadCounter();
    LSM303DLH_I2C_Init();

    IWDG_ReloadCounter();
    LSM303_Config();

    IWDG_ReloadCounter();
    L3G_Config();
}


