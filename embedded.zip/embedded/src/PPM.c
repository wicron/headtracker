/*
 * PPM.c
 *
 *  Created on: 31.05.2012
 *      Author: delphi
 */

#define minPPM 400u
#define maxPPM 2200u
#define relaxTime 6000u
#include "PPM.h"
#include "gui.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "led.h"
#include "lcd.h"
#include "ins.h"
#include "ins_algorithm.h"

TIM_TypeDef* PPM_TIM=TIM3;
#define PPM_CH       TIM_Channel_3
#define PPM_CAP_INT  TIM_IT_CC3

#define highPassFilterValue    400u
#define lowPassFilterValue     3000u

uint16_t PPM_IN[NUM_CHANNELS]={1250,1250,1250,1250,1250,1250,1250,1250};
uint16_t currentChannel=0;
uint16_t zeroFlag=0;
uint16_t waitPeriod=350;

uint16_t PPM_timing[NUM_CHANNELS+1]={1250,1250,1250,1250,1250,1250,1250,1250,7150}; //time of each PPM signal in us
uint16_t PPM_angle[NUM_CHANNELS]={90,90,90,90,90,90,90,90};

#define TIMER_TAKT  72
#define SYSTEM_TIMERCLOCK 72000000
//#define TIM3_CC_IRQChannel       3
uint16_t captureFlag;
uint16_t jawBreak;
uint16_t rollBreak;
uint16_t pitchBreak;

void initPPM(void)
{
	GPIO_InitTypeDef   GPIO_INIT_PPM;
	RCC_APB2PeriphClockCmd(PPM_RCC_Port, ENABLE);
	GPIO_INIT_PPM.GPIO_Pin =  PPM_Pin;
	GPIO_INIT_PPM.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_INIT_PPM.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(PPM_Port, &GPIO_INIT_PPM);

	GPIO_InitTypeDef   GPIO_INIT_PPM_IN;
	GPIO_INIT_PPM_IN.GPIO_Pin =  PPM_IN_Pin;
	GPIO_INIT_PPM_IN.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_INIT_PPM_IN.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(PPM_IN_Port, &GPIO_INIT_PPM_IN);
    initPPM_OUT();
	initPPM_IN();

}

void initPPM_OUT(void)
{
	  /* �� �������� ������������� ������ */
	 RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;     // ��� ���������, ������� ������������ ������
	        TIM2->ARR = 7000;              // ����. �������� �� �������� �������
	        TIM2->PSC = 56;                // ����������� ���
	        TIM2->CR1 |= TIM_CR1_CEN;       // �������� ����
	        TIM2->DIER |= TIM_DIER_UIE;     // ���������� �� ����������
	  NVIC_SetPriority(TIM2_IRQn, 0);
	  NVIC_EnableIRQ(TIM2_IRQn);
	 // convertAngle_to_PPM();
	}

	void TIM2_IRQHandler()
	{
	//	 __disable_irq();
	  /* ��� ��� ���� ���������� ���������� , ����� ���������,
	   * ��������� �� ���������� �� ������������ �������� ������� TIM2.
	   */
	  if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	  {
	    /* ������� ��� ��������������� ���������� */
	    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	    /* ����������� ��������� ����������� */
      }
	    TIM2->ARR  = getTimePPM_OUT(); // ��������� ��������� �������
	  //  blinkLed1();
//	    __enable_irq();
	  return;
	}

void convertPPM_to_angle()
{
        for (int i=0;i<NUM_CHANNELS;++i)
	{
		PPM_angle[i]=180*(PPM_IN[i]-minPPM)/(maxPPM-minPPM)>0 ? 180*(PPM_IN[i]-minPPM)/(maxPPM-minPPM):0;
	}
}

void convertAngle_to_PPM()
{
	uint16_t temp;
        for (int i=0;i<NUM_CHANNELS;++i)
	{
		PPM_timing[i]=minPPM+(maxPPM-minPPM)*PPM_angle[i]/(180);
	}
        temp=0;
        	  for (int i=0;i<NUM_CHANNELS;++i)
        		{
        			temp+=PPM_timing[i];
        		}

        	PPM_timing[NUM_CHANNELS]=20000-temp;

}


uint16_t getTimePPM_OUT()
{
	uint16_t currentPPM;

    if (zeroFlag){currentPPM=waitPeriod; (_headTrackerParameters.d.dir==negative) ? clearPPM : setPPM;} else
		{
		currentPPM=PPM_timing[currentChannel];
		currentChannel=(currentChannel+1)%(NUM_CHANNELS+1);
        (_headTrackerParameters.d.dir==negative) ? setPPM : clearPPM;
		}
	zeroFlag=(zeroFlag+1)%2;
    return currentPPM;
}

void setAngleToChannel(uint16_t value,uint16_t channel)
{
	PPM_angle[channel-1]=value;
}


uint32_t getTimer()
{
  return 1;
}


void capturePPM_IN()
{
	TIM_Cmd(TIM3, ENABLE);
}


void TIMER_InitInputCaptureTimer(TIM_TypeDef* TIMx, uint16_t tmrchannel, uint16_t period)
{
  TIM_ICInitTypeDef  TIM_ICInitStructure;
 //TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
 uint16_t PrescalerValue = (uint16_t) ( TIMER_TAKT) - 1;

   //TIM_TimeBaseStructure.TIM_Period       = period -1; //65535;
 //  TIM_TimeBaseStructure.TIM_Prescaler     = (TIMER_TAKT - 1); //0;
   //TIM_TimeBaseStructure.TIM_ClockDivision    = 0;
   //TIM_TimeBaseStructure.TIM_CounterMode     = TIM_CounterMode_Up;
   //TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  // TIM_TimeBaseInit(TIMx, &TIM_TimeBaseStructure);

 TIM_PrescalerConfig(TIMx, PrescalerValue, TIM_PSCReloadMode_Immediate);

 TIM_ICInitStructure.TIM_Channel = tmrchannel; //TIM_Channel_3;
   TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_BothEdge;
   TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
   TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;      // Div:1, every edge
   TIM_ICInitStructure.TIM_ICFilter = 0x3;
   TIM_ICInit(TIMx, &TIM_ICInitStructure);

 /* Enable the CC3 Interrupt Request */
   TIM_ClearITPendingBit(TIMx, PPM_CAP_INT); //TIM_IT_CC3);
 TIM_ITConfig(TIMx, PPM_CAP_INT, ENABLE);
 TIM_Cmd(TIMx, ENABLE);


}


void TIMER_Init(TIM_TypeDef* TIMx, uint16_t tmrchannel, uint16_t irqchannel,
 uint16_t period)
{
 NVIC_InitTypeDef NVIC_InitStructure;
 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
   TIMER_InitInputCaptureTimer(TIMx, tmrchannel, period);
   NVIC_InitStructure.NVIC_IRQChannel = irqchannel; //TIM3_CC_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);
   NVIC_EnableIRQ(TIM3_IRQn);

}

volatile uint16_t captureNumber = 0;
volatile uint16_t timeCapture = 0;

int d2i(float d)
{
 float value;
 value = d;
 value /= 10;
 value += 0.5;
 return value;
}



//void TIM3_CC_IRQHandler (void)
void TIM3_IRQHandler(void)
{
	// __disable_irq();
	 if (TIM_GetITStatus(TIM3, TIM_IT_CC3) != RESET)
	   {
	     /* ��� �����, ��� ���������� ���������� */
	     TIM_ClearITPendingBit(TIM3, TIM_IT_CC3);
	PPM_TIM->SR &= TIM_IT_CC3;
  /* capture timer */

  //clear pending bit
    PPM_TIM->SR = (uint16_t)~TIM_FLAG_CC3;

       /* Get the Input Capture value */
       timeCapture = TIM_GetCapture3(PPM_TIM);
       if (timeCapture>lowPassFilterValue)  captureNumber=0; else
       if (timeCapture>highPassFilterValue) {PPM_IN[captureNumber]=timeCapture;captureNumber=(captureNumber+1)%(NUM_CHANNELS);}
    //

  /* flag: new rising edge interrupt INTR received */

   //zero to counter register

 /* clear all flags */
  PPM_TIM->SR = ~0xFF;
  /* ��� ���-������ ������������ ������� over-capture, ���� ���������� */
   if (TIM_GetFlagStatus(TIM3, TIM_FLAG_CC3OF) != RESET)
   {
     TIM_ClearFlag(TIM3, TIM_FLAG_CC3OF);

    // blinkLed1();
   }
	   }

    TIM_SetCounter(PPM_TIM,0);
  //__enable_irq();
  return;
 }



void initPPM_IN(void)
{
	TIMER_Init(PPM_TIM,PPM_CH,PPM_CAP_INT,0xFFFF);
}

int16_t jawDir=yes;
int16_t rollDir=yes;
int16_t pitchDir=yes;


int16_t jawCurrent=0;
int16_t rollCurrent=0;
int16_t pitchCurrent=0;

int16_t jawTemp=0;
int16_t rollTemp=0;
int16_t pitchTemp=0;

int16_t jawOut=0;
int16_t rollOut=0;
int16_t pitchOut=0;

int16_t diffJawTemp=0;
int16_t diffRollTemp=0;
int16_t diffPitchTemp=0;

void initAngle(void)
{
jawTemp=_headAngle.jaw*_headTrackerParameters.d.jawRate/ANGLE_SCALE;
rollTemp=_headAngle.roll*_headTrackerParameters.d.jawRate/ANGLE_SCALE;
pitchTemp=_headAngle.pitch*_headTrackerParameters.d.jawRate/ANGLE_SCALE;
}


void clearAngles(void)
{
        simpleInsInit();
	jawOut=0;
	rollOut=0;
	pitchOut=0;
}

void refreshPPM(void)
{
/*
    jawTemp=_headAngle.jaw*_headTrackerParameters.d.jawRate/ANGLE_SCALE;
    rollTemp= _headAngle.roll*_headTrackerParameters.d.rollRate/ANGLE_SCALE;
    pitchTemp=_headAngle.pitch*_headTrackerParameters.d.rollRate/ANGLE_SCALE;
*/
	/*
	jawBreak=diffJawTemp-(jawTemp-jawStart);
	rollBreak=diffRollTemp-(rollTemp-rollStart);
	pitchBreak=diffPitchTemp-(pitchTemp-pitchStart);

	if (abs(jawBreak)>100)  jawStart=jawStart+jawBreak;
	if (abs(rollBreak)>100) rollStart=rollStart+rollBreak;
	if (abs(pitchBreak)>100) pitchStart=pitchStart+pitchBreak;

	diffJawTemp=(jawTemp-jawStart);
	diffRollTemp=(rollTemp-rollStart);
	diffPitchTemp=(pitchTemp-pitchStart);
     */

    if (_headTrackerParameters.d.jawDir==yes) jawDir=1;else jawDir=-1;
    if (_headTrackerParameters.d.rollDir==yes) rollDir=1;else rollDir=-1;
    if (_headTrackerParameters.d.pitchDir==yes) pitchDir=1;else pitchDir=-1;

     jawCurrent=_headAngle.jaw*_headTrackerParameters.d.jawRate/ANGLE_SCALE;
     rollCurrent=_headAngle.roll*_headTrackerParameters.d.rollRate/ANGLE_SCALE;
     pitchCurrent=_headAngle.pitch*_headTrackerParameters.d.pitchRate/ANGLE_SCALE;

	diffJawTemp=jawCurrent-jawTemp;
	diffRollTemp=rollCurrent-rollTemp;
	diffPitchTemp=pitchCurrent-pitchTemp;

	if (abs(diffJawTemp)>80)    diffJawTemp=0;
	if (abs(diffRollTemp)>80)   diffRollTemp=0;
	if (abs(diffPitchTemp)>80)  diffPitchTemp=0;

	jawOut=jawOut+diffJawTemp;
	rollOut=rollOut+diffRollTemp;
	pitchOut=pitchOut+diffPitchTemp;

    if (jawOut>_headTrackerParameters.d.jawLimitMax) jawOut=_headTrackerParameters.d.jawLimitMax;
    if (rollOut>_headTrackerParameters.d.jawLimitMax) rollOut=_headTrackerParameters.d.rollLimitMax;
    if (pitchOut>_headTrackerParameters.d.pitchLimitMax) pitchOut=_headTrackerParameters.d.pitchLimitMax;

    if (jawOut<-_headTrackerParameters.d.jawLimitMin) jawOut=-_headTrackerParameters.d.jawLimitMin;
    if (rollOut<-_headTrackerParameters.d.rollLimitMin) rollOut=-_headTrackerParameters.d.rollLimitMin;
    if (pitchOut<-_headTrackerParameters.d.pitchLimitMin) pitchOut=-_headTrackerParameters.d.pitchLimitMin;

	if (jawOut>90) jawOut=90;
	if (rollOut>90) rollOut=90;
	if (pitchOut>90) pitchOut=90;

	if (jawOut<-90) jawOut=-90;
	if (rollOut<-90) rollOut=-90;
	if (pitchOut<-90) pitchOut=-90;

	jawTemp=jawCurrent;
	rollTemp=rollCurrent;
	pitchTemp=pitchCurrent;

    setAngleToChannel((uint16_t)(90+jawOut*jawDir),_headTrackerParameters.d.yawChannel);
    setAngleToChannel((uint16_t)(90+rollOut*rollDir),_headTrackerParameters.d.rollChannel);
    setAngleToChannel((uint16_t)(90+pitchOut*pitchDir),_headTrackerParameters.d.pitchChannel);

	//convertPPM_to_angle();
     convertAngle_to_PPM();

     if(_headTrackerParameters.d.mode==mix) {

	 for (int i=0;i<NUM_CHANNELS;++i)
	    {
 if ((i!=(_headTrackerParameters.d.yawChannel-1))&&
         (i!=(_headTrackerParameters.d.rollChannel-1))&&
         (i!=(_headTrackerParameters.d.pitchChannel-1)))
		 PPM_timing[i]=PPM_IN[i];
	    }
	 }
	 }

void getCapture(void)
{
	    convertPPM_to_angle();
		char buf[6];
        Lcd_clear();
        Lcd_goto(0,0);
        sprintf (buf, "%i",timeCapture);
        Lcd_write_string(buf);

}

