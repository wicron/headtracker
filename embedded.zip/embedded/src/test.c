/*
 * test.c
 *
 *  Created on: 04.09.2012
 *      Author: DELPHI
 */

#include "test.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "stm32f10x.h"
#include "lcd.h"
#include "test.h"
#include "PPM.h"
#include "RTC.h"
#include "ins.h"
#include "delay.h"
#include "led.h"
#include "hint.h"
#include "LSM303DLHC.h"
#include "L3G4200.h"

#include "state/state.h"
#include "state/measurment.h"

#include "eeprom.h"


void testLSM303(void)
{
	 s16 out[3];
		 char buf[6];
		 while (1)
		    {
			 IWDG_ReloadCounter();
		    	Lcd_clear();
		    	Lcd_goto(0,0);
		    	LSM303DLH_Magn_Read_Magn(out);
		    	sprintf (buf, "%i",(int16_t)(out[0]));
		    	Lcd_write_string(buf);
		    //	Lcd_write_string(";");
		    	//sprintf (buf, "%i",(uint8_t)(out[1]>>8));
		    	//Lcd_write_string(buf);
		    	LSM303DLH_Acc_Read_Acc(out);
		    	Lcd_goto(1,0);
		    	sprintf (buf, "%i",(int16_t)(out[0]));
		     	Lcd_write_string(buf);
		    	blinkLed1();
		    }
}


void testLSM303DLHC_Magn(void)
{
	 s16 out[3];
	 char buf[6];
	 while (1)
	    {
		 IWDG_ReloadCounter();
	    	Lcd_clear();
	    	Lcd_goto(0,0);
	    	LSM303DLH_Magn_Read_Magn(out);
	    	sprintf (buf, "%i",(int16_t)(out[0]));
	    	Lcd_write_string(buf);
	    //	Lcd_write_string(";");
	    	//sprintf (buf, "%i",(uint8_t)(out[1]>>8));
	    	//Lcd_write_string(buf);
	    	Lcd_goto(1,0);
	    	sprintf (buf, "%i",(int16_t)(out[2]));
	     	Lcd_write_string(buf);
	    	blinkLed1();
	    }
}


void testLSM303DLHC_Acc(void)
{
	 s16 out[3];
	 char buf[6];
	 while (1)
	    {
		 IWDG_ReloadCounter();
	    	Lcd_clear();
	    	Lcd_goto(0,0);
	    	LSM303DLH_Acc_Read_Acc(out);
	    	sprintf (buf, "%i",(int16_t)(out[0]));
	    	Lcd_write_string(buf);
	    //	Lcd_write_string(";");
	    	//sprintf (buf, "%i",(uint8_t)(out[1]>>8));
	    	//Lcd_write_string(buf);
	    	Lcd_goto(1,0);
	    	sprintf (buf, "%i",(int16_t)(out[2]));
	     	Lcd_write_string(buf);
	    	blinkLed1();
	    }
}

void testL3G4200(void)
{
	 s16 out[3];
	 char buf[6];
	 while (1)
	    {
		 IWDG_ReloadCounter();
	    	Lcd_clear();
	    	Lcd_goto(0,0);
	    	L3G4200_Read_RawData(out);
	    	sprintf (buf, "%i",(int16_t)(out[0]));
	    	Lcd_write_string(buf);
	    	//Lcd_write_string(";");
	    	//sprintf (buf, "%i",(int16_t)(out[1]));
	    //	Lcd_write_string(buf);
	    	Lcd_goto(1,0);
	    	sprintf (buf, "%i",(int16_t)(out[2]));
	     	Lcd_write_string(buf);
	    	blinkLed1();
	    }
}

void testEeprom()
{
    HeadTrackerParameters temp=_headTrackerParameters;
    HeadTrackerParameters test;
    uint8_t counter =0;
    for(uint8_t* p=(uint8_t*)&test; p<(uint8_t*)((&test)+1); ++p, ++counter)
        *p = counter;
    _headTrackerParameters = test;
    saveParametersToEEPROM();
    memset(&_headTrackerParameters, 0x0, sizeof(HeadTrackerParameters));
    loadParametersFromEEPROM();

    Lcd_clear();
    Lcd_goto(0,0);
    Lcd_write_string("Mem test");
    if(memcmp(&test, &_headTrackerParameters, sizeof(HeadTrackerParameters)))
    {
        Lcd_goto(1,0);
        Lcd_write_string("failed");
    }else{
        Lcd_goto(1,0);
        Lcd_write_string("passed");
    }
    _headTrackerParameters = temp;

    saveParametersToEEPROM();
}
