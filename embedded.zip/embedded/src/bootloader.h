/*
 * bootloader.h
 *
 *  Created on: 22.11.2012
 *      Author: delphi
 */

#ifndef BOOTLOADER_H_
#define BOOTLOADER_H_

void hardEnterSoftwareDFUbootloader(void);
void safeEnterHardwareDFUbootloader(void);

void systemDefault(void);

#endif /* BOOTLOADER_H_ */
