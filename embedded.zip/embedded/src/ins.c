/*
 * ins.c
 *
 *  Created on: 04.09.2012
 *      Author: DELPHI
 */
#include "ins.h"
#include "stm32f10x.h"

#include "ins_algorithm.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "stm32f10x.h"
#include "lcd.h"

#include "RTC.h"
#include "ins.h"
#include "delay.h"
#include "led.h"
#include "hint.h"

#include "state/state.h"
#include "state/measurment.h"

void ins(float *angleZ, float *angleY)
{
    static uint32_t insCurTick=0;
    static uint32_t insPrevTick=0;

    float gyro[3], magn[3], accel[3];

    if(!insCurTick && !insPrevTick){
        insCurTick = RTC_GetCounter();
        insPrevTick = RTC_GetCounter();
    }

    insCurTick = RTC_GetCounter();
    float dt = (insCurTick-insPrevTick)>0 ? (insCurTick-insPrevTick)*TIME_SCALE : 0;
    insPrevTick = insCurTick;

    readInsSensors(gyro, accel, magn);
    InsPredict(gyro, accel, magn, dt);
    InsCorrect(gyro, accel, magn, dt);
    InsGetAngles(angleZ, angleY, _headTrackerParameters.d.position);

    _headAngle.jaw = (*angleZ)*ANGLE_SCALE;
    _headAngle.pitch = (*angleY)*ANGLE_SCALE;
    _updatedReports |= (1<<ANGLE_REPORT_ID);
}

void readInsSensors(float gyro[3], float accel[3], float magn[3]){
    //! @todo Add code for reading from sensors
    getDataFromSensors();

    float q[4];
    InsGetQuaternione(q);
    for(int i=0; i<4; ++i){
        _headAngle.q[i] = q[i]*ANGLE_SCALE;
    }
    if(_updatedReports & (1<<MEASURMENT_REPORT_ID))
        for(int i =0; i< 3; ++i){
            gyro[i] = _measurments.gyro[i]*HT_GYRO_SCALE;
            accel[i] = _measurments.accel[i]*HT_ACCEL_SCALE;
            magn[i] = _measurments.magn[i]*HT_MAGN_SCALE;
        }
}

void simpleInsInit(){
    float gyro[3], accel[3], magn[3];
    readInsSensors(gyro, accel, magn);
    InsInit(magn, accel);
}
