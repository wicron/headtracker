/*
 * PPM.h
 *
 *  Created on: 31.05.2012
 *      Author: delphi
 */

#ifndef PPM_H_
#define PPM_H_

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stm32f10x.h"
#include "state/state.h"

#define PPM_Port             GPIOB
#define PPM_Pin              GPIO_Pin_1
#define PPM_RCC_Port         RCC_APB2Periph_GPIOB

#define PPM_IN_Port          GPIOB
#define PPM_IN_Pin           GPIO_Pin_0
#define PPM_IN_RCC_Port      RCC_APB2Periph_GPIOB

#define setPPM               GPIO_SetBits(PPM_Port,PPM_Pin)
#define clearPPM             GPIO_ResetBits(PPM_Port,PPM_Pin)

#define readPPM_IN           GPIO_ReadInputDataBit(PPM_IN_Port,PPM_IN_Pin)
void initPPM_OUT(void);
void convertPPM_to_angle(void);
void convertAngle_to_PPM(void);
uint16_t getTimePPM_OUT(void);
void setAngleToChannel(uint16_t value,uint16_t channel);
uint32_t getTimer(void);
void capturePPM_IN(void);
void   EXTI9_5_IRQHandler(void);
void TIMER_Init(TIM_TypeDef* TIMx, uint16_t tmrchannel, uint16_t irqchannel, uint16_t period);
void TIM3_CC_IRQHandler (void);
void initPPM_IN(void);
void initPPM(void);
void refreshPPM(void);
void initAngle(void);
void getCapture(void);
void clearAngles(void);
#endif /* PPM_H_ */
